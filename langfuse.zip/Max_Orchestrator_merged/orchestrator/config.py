"""
orchestrator.config
===================
Centralised configuration loaded from environment variables.

Every tunable knob in the orchestrator lives here so that ``main.py`` is
the only module that ever reads ``os.environ`` at import-time.

Usage
-----
::

    from orchestrator.config import get_config
    cfg = get_config()
    print(cfg.langfuse.enabled)
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache


# ═══════════════════════════════════════════════════════════════════════════
#  LANGFUSE
# ═══════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class LangfuseConfig:
    """
    Self-hosted Langfuse observability configuration.

    Set ``LANGFUSE_ENABLED=true`` to activate tracing.  All other fields
    are required only when enabled.
    """

    enabled: bool = False
    host: str = "http://localhost:3000"
    public_key: str = ""
    secret_key: str = ""
    project_name: str = "max-orchestrator"
    environment: str = "development"
    flush_interval_seconds: float = 5.0
    sample_rate: float = 1.0  # 1.0 = trace every request

    @classmethod
    def from_env(cls) -> LangfuseConfig:
        return cls(
            enabled=os.getenv("LANGFUSE_ENABLED", "false").lower() in ("true", "1", "yes"),
            host=os.getenv("LANGFUSE_HOST", "http://localhost:3000"),
            public_key=os.getenv("LANGFUSE_PUBLIC_KEY", ""),
            secret_key=os.getenv("LANGFUSE_SECRET_KEY", ""),
            project_name=os.getenv("LANGFUSE_PROJECT_NAME", "max-orchestrator"),
            environment=os.getenv("LANGFUSE_ENVIRONMENT", "development"),
            flush_interval_seconds=float(os.getenv("LANGFUSE_FLUSH_INTERVAL", "5.0")),
            sample_rate=float(os.getenv("LANGFUSE_SAMPLE_RATE", "1.0")),
        )


# ═══════════════════════════════════════════════════════════════════════════
#  POSTGRES (LangGraph checkpointer)
# ═══════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class PostgresConfig:
    """PostgreSQL connection for the LangGraph checkpointer."""

    connection_string: str = (
        "postgresql+asyncpg://max:max@localhost:5432/max_orchestrator"
    )
    pool_size: int = 10
    max_overflow: int = 5

    @classmethod
    def from_env(cls) -> PostgresConfig:
        return cls(
            connection_string=os.getenv(
                "PG_CONNECTION_STRING",
                "postgresql+asyncpg://max:max@localhost:5432/max_orchestrator",
            ),
            pool_size=int(os.getenv("PG_POOL_SIZE", "10")),
            max_overflow=int(os.getenv("PG_MAX_OVERFLOW", "5")),
        )


# ═══════════════════════════════════════════════════════════════════════════
#  AZURE OPENAI
# ═══════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class AzureOpenAIConfig:
    """Azure OpenAI model deployments and credentials."""

    embedding_deployment: str = "text-embedding-3-small"
    fallback_llm_deployment: str = "gpt-4o-mini"
    fallback_llm_temperature: float = 0.0
    fallback_llm_max_tokens: int = 256
    api_key: str = ""
    endpoint: str = ""
    api_version: str = "2024-02-01"

    @classmethod
    def from_env(cls) -> AzureOpenAIConfig:
        return cls(
            embedding_deployment=os.getenv(
                "AZURE_EMBEDDING_DEPLOYMENT", "text-embedding-3-small"
            ),
            fallback_llm_deployment=os.getenv(
                "AZURE_FALLBACK_LLM_DEPLOYMENT", "gpt-4o-mini"
            ),
            fallback_llm_temperature=float(
                os.getenv("AZURE_FALLBACK_LLM_TEMPERATURE", "0.0")
            ),
            fallback_llm_max_tokens=int(
                os.getenv("AZURE_FALLBACK_LLM_MAX_TOKENS", "256")
            ),
            api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
            endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
            api_version=os.getenv("OPENAI_API_VERSION", "2024-02-01"),
        )


# ═══════════════════════════════════════════════════════════════════════════
#  DOWNSTREAM SERVICE ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class ServiceEndpoints:
    """Base URLs for every downstream micro-service the orchestrator calls."""

    policy_search_url: str = "http://localhost:8001"
    l1_aiops_url: str = "http://localhost:8002"
    l2_classifier_url: str = "http://localhost:8003"
    hr_service_url: str = "http://localhost:8004"
    speech_service_url: str = "http://localhost:8005"
    device_registry_url: str = "http://localhost:8006"
    icap_scanner_url: str = "http://localhost:8007"
    feedback_service_url: str = "http://localhost:8008"
    sso_service_url: str = "http://localhost:8009"

    @classmethod
    def from_env(cls) -> ServiceEndpoints:
        return cls(
            policy_search_url=os.getenv("POLICY_SEARCH_URL", "http://localhost:8001"),
            l1_aiops_url=os.getenv("L1_AIOPS_URL", "http://localhost:8002"),
            l2_classifier_url=os.getenv("L2_CLASSIFIER_URL", "http://localhost:8003"),
            hr_service_url=os.getenv("HR_SERVICE_URL", "http://localhost:8004"),
            speech_service_url=os.getenv("SPEECH_SERVICE_URL", "http://localhost:8005"),
            device_registry_url=os.getenv("DEVICE_REGISTRY_URL", "http://localhost:8006"),
            icap_scanner_url=os.getenv("ICAP_SCANNER_URL", "http://localhost:8007"),
            feedback_service_url=os.getenv("FEEDBACK_SERVICE_URL", "http://localhost:8008"),
            sso_service_url=os.getenv("SSO_SERVICE_URL", "http://localhost:8009"),
        )


# ═══════════════════════════════════════════════════════════════════════════
#  FEATURE FLAGS
# ═══════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class FeatureFlags:
    """Runtime feature flags – all toggleable via env vars."""

    max_orchestrator_call: bool = True  # spec §5 – L2 child classifier
    l2_classifier_enabled: bool = True
    prompt_max_length: int = 500
    router_confidence_threshold: float = 0.85
    request_timeout_seconds: float = 30.0
    input_url_validation_enabled: bool = True

    @classmethod
    def from_env(cls) -> FeatureFlags:
        return cls(
            max_orchestrator_call=os.getenv("MAX_ORCHESTRATOR_CALL", "true").lower()
            in ("true", "1"),
            l2_classifier_enabled=os.getenv("L2_CLASSIFIER_ENABLED", "true").lower()
            in ("true", "1"),
            prompt_max_length=int(os.getenv("PROMPT_MAX_LENGTH", "500")),
            router_confidence_threshold=float(
                os.getenv("ROUTER_CONFIDENCE_THRESHOLD", "0.85")
            ),
            request_timeout_seconds=float(
                os.getenv("REQUEST_TIMEOUT_SECONDS", "30.0")
            ),
            input_url_validation_enabled=os.getenv(
                "INPUT_URL_VALIDATION_ENABLED", "true"
            ).lower()
            in ("true", "1"),
        )


# ═══════════════════════════════════════════════════════════════════════════
#  AGGREGATED APP CONFIG
# ═══════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class AppConfig:
    """Top-level configuration container.  Instantiate once via ``from_env()``."""

    langfuse: LangfuseConfig = field(default_factory=LangfuseConfig)
    postgres: PostgresConfig = field(default_factory=PostgresConfig)
    azure_openai: AzureOpenAIConfig = field(default_factory=AzureOpenAIConfig)
    services: ServiceEndpoints = field(default_factory=ServiceEndpoints)
    features: FeatureFlags = field(default_factory=FeatureFlags)

    @classmethod
    def from_env(cls) -> AppConfig:
        return cls(
            langfuse=LangfuseConfig.from_env(),
            postgres=PostgresConfig.from_env(),
            azure_openai=AzureOpenAIConfig.from_env(),
            services=ServiceEndpoints.from_env(),
            features=FeatureFlags.from_env(),
        )


@lru_cache(maxsize=1)
def get_config() -> AppConfig:
    """Return the immutable, cached application configuration."""
    return AppConfig.from_env()
