"""
orchestrator.services.feedback_service
=======================================
Client for the **Feedback Persistence** downstream service.

Handles spec §2 endpoint: ``POST /feedback``.
"""

from __future__ import annotations

import logging
from typing import Any

from orchestrator.services.base_client import BaseServiceClient

logger = logging.getLogger(__name__)


class FeedbackServiceClient(BaseServiceClient):
    """Async client for persisting user feedback."""

    def __init__(self, base_url: str, **kwargs: Any) -> None:
        super().__init__(base_url, service_name="FeedbackService", **kwargs)

    async def submit_feedback(
        self,
        feedback_data: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Persist user feedback.

        ``POST /api/v1/feedback``

        Parameters
        ----------
        feedback_data
            ``{"session_id": str, "correlation_id": str, "rating": int,
               "comment": str, "category": str}``
        """
        logger.info(
            "Feedback: submit session=%s rating=%s",
            feedback_data.get("session_id", ""),
            feedback_data.get("rating", "N/A"),
        )
        return await self.post("/api/v1/feedback", json_data=feedback_data)
