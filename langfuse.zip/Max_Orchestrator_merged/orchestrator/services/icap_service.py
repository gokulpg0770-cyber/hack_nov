"""
orchestrator.services.icap_service
===================================
Client for the **ICAP file scanner** downstream service.

Handles spec §2 endpoint: ``POST /file-scan``.
"""

from __future__ import annotations

import logging
from typing import Any

from orchestrator.services.base_client import BaseServiceClient

logger = logging.getLogger(__name__)


class ICAPScannerClient(BaseServiceClient):
    """Async client for ICAP-based malware / content scanning."""

    def __init__(self, base_url: str, **kwargs: Any) -> None:
        super().__init__(base_url, service_name="ICAPScannerService", **kwargs)

    async def scan_file(
        self,
        file_data: bytes,
        filename: str = "upload",
        content_type: str = "application/octet-stream",
    ) -> dict[str, Any]:
        """
        Scan a file for malware / policy violations via ICAP.

        Returns
        -------
        dict
            ``{"clean": bool, "threats": [...], "scan_id": str}``
        """
        logger.info(
            "ICAP: scan file=%s size=%d content_type=%s",
            filename,
            len(file_data),
            content_type,
        )
        client = await self._get_client()
        resp = await client.post(
            "/api/v1/scan",
            files={"file": (filename, file_data, content_type)},
        )
        resp.raise_for_status()
        return resp.json()
