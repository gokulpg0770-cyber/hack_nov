"""
orchestrator.services.base_client
=================================
Abstract HTTP client that all downstream service adapters extend.

Features
--------
*  Connection pooling via ``httpx.AsyncClient``.
*  Automatic retry-on-transient-failure (503/429) with exponential back-off.
*  Structured JSON logging with timing metadata.
*  Langfuse span creation via the request-scoped ``RequestTimer``.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Optional

import httpx

from orchestrator.observability import get_request_timer

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT = 30.0
_MAX_RETRIES = 2
_BACKOFF_BASE = 0.3  # seconds


class ServiceError(Exception):
    """Raised when a downstream service returns an unrecoverable error."""

    def __init__(
        self,
        service: str,
        status_code: int = 0,
        detail: str = "",
    ) -> None:
        self.service = service
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"{service} error (HTTP {status_code}): {detail}")


class BaseServiceClient:
    """
    Thin async HTTP wrapper.

    Subclasses only need to implement domain-specific methods; all
    networking concerns are handled here.
    """

    def __init__(
        self,
        base_url: str,
        timeout: float = _DEFAULT_TIMEOUT,
        service_name: str = "",
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.service_name = service_name or type(self).__name__
        self._client: Optional[httpx.AsyncClient] = None

    # ── Client lifecycle ────────────────────────────────────────────────

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=httpx.Timeout(self.timeout),
                headers={
                    "Content-Type": "application/json",
                    "X-Source": "max-orchestrator",
                },
            )
        return self._client

    async def close(self) -> None:
        """Gracefully close the connection pool."""
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
            self._client = None
            logger.info("%s: connection pool closed.", self.service_name)

    # ── Core HTTP verbs ─────────────────────────────────────────────────

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json_data: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
        content: Optional[bytes] = None,
    ) -> dict[str, Any]:
        """
        Fire an HTTP request with timing, logging, and retry logic.

        Returns the parsed JSON body on success; raises ``ServiceError``
        on terminal failure.
        """
        client = await self._get_client()
        timer = get_request_timer()
        op_label = f"http_{method.lower()}_{self.service_name}"

        last_exc: Optional[Exception] = None

        for attempt in range(1, _MAX_RETRIES + 2):  # attempts 1 … N+1
            t0 = time.perf_counter()
            try:
                with timer.time_operation(
                    op_label,
                    service=self.service_name,
                    path=path,
                    attempt=attempt,
                ):
                    resp = await client.request(
                        method,
                        path,
                        json=json_data,
                        params=params,
                        headers=headers,
                        content=content,
                    )

                if resp.status_code in (429, 503) and attempt <= _MAX_RETRIES:
                    wait = _BACKOFF_BASE * (2 ** (attempt - 1))
                    logger.warning(
                        "%s: transient %d on %s %s – retrying in %.1fs (attempt %d/%d)",
                        self.service_name,
                        resp.status_code,
                        method,
                        path,
                        wait,
                        attempt,
                        _MAX_RETRIES + 1,
                    )
                    import asyncio

                    await asyncio.sleep(wait)
                    continue

                resp.raise_for_status()

                try:
                    return resp.json()
                except Exception:
                    return {"raw": resp.text}

            except httpx.HTTPStatusError as exc:
                raise ServiceError(
                    service=self.service_name,
                    status_code=exc.response.status_code,
                    detail=exc.response.text[:500],
                ) from exc
            except httpx.RequestError as exc:
                last_exc = exc
                if attempt <= _MAX_RETRIES:
                    import asyncio

                    wait = _BACKOFF_BASE * (2 ** (attempt - 1))
                    logger.warning(
                        "%s: connection error on %s %s – retrying in %.1fs",
                        self.service_name,
                        method,
                        path,
                        wait,
                    )
                    await asyncio.sleep(wait)
                    continue
                break

        raise ServiceError(
            service=self.service_name,
            detail=f"All {_MAX_RETRIES + 1} attempts failed: {last_exc}",
        )

    # ── Convenience methods ─────────────────────────────────────────────

    async def post(
        self,
        path: str,
        json_data: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        return await self._request("POST", path, json_data=json_data, **kwargs)

    async def get(
        self,
        path: str,
        params: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        return await self._request("GET", path, params=params, **kwargs)

    async def put(
        self,
        path: str,
        json_data: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        return await self._request("PUT", path, json_data=json_data, **kwargs)
