"""
orchestrator.services.hr_service
================================
Client for the **HR / HRIS** downstream service.

Consolidates all HR-domain APIs behind a single client:
*  Self Info        (spec §4 tool #5)
*  Leave Balance    (spec §4 tool #4)
*  Leave Manager    (spec §4 tool #10)
*  Timesheet        (spec §4 tool #9)
*  HIS Plan         (spec §4 tool #6)
*  Beneficiaries    (spec §4 tool #7)
*  Associate Data   (spec §2 endpoint)
"""

from __future__ import annotations

import logging
from typing import Any

from orchestrator.services.base_client import BaseServiceClient

logger = logging.getLogger(__name__)


class HRServiceClient(BaseServiceClient):
    """
    Async client for the HR / HRIS micro-service.

    Every method corresponds to one of the legacy "direct capabilities"
    from spec §4.
    """

    def __init__(self, base_url: str, **kwargs: Any) -> None:
        super().__init__(base_url, service_name="HRService", **kwargs)

    # ── Self Info ───────────────────────────────────────────────────────

    async def get_self_info(self, employee_id: str) -> dict[str, Any]:
        """
        Retrieve the employee's profile information.

        ``GET /api/v1/employees/{employee_id}/profile``
        """
        logger.info("HR: get_self_info employee=%s", employee_id)
        return await self.get(f"/api/v1/employees/{employee_id}/profile")

    # ── Leave Balance ──────────────────────────────────────────────────

    async def get_leave_balance(self, employee_id: str) -> dict[str, Any]:
        """
        Retrieve the employee's remaining leave / PTO balance.

        ``GET /api/v1/employees/{employee_id}/leave-balance``
        """
        logger.info("HR: get_leave_balance employee=%s", employee_id)
        return await self.get(f"/api/v1/employees/{employee_id}/leave-balance")

    # ── Leave Manager ──────────────────────────────────────────────────

    async def manage_leave(
        self,
        employee_id: str,
        action: str,
        leave_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Apply for, cancel, or modify a leave request.

        ``POST /api/v1/employees/{employee_id}/leave``

        Parameters
        ----------
        action
            ``"apply"`` | ``"cancel"`` | ``"modify"``
        leave_data
            Leave details (dates, type, reason, etc.).
        """
        logger.info("HR: manage_leave employee=%s action=%s", employee_id, action)
        return await self.post(
            f"/api/v1/employees/{employee_id}/leave",
            json_data={"action": action, **(leave_data or {})},
        )

    # ── Timesheet ──────────────────────────────────────────────────────

    async def manage_timesheet(
        self,
        employee_id: str,
        action: str,
        timesheet_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Submit, correct, or query timesheet entries.

        ``POST /api/v1/employees/{employee_id}/timesheet``
        """
        logger.info("HR: manage_timesheet employee=%s action=%s", employee_id, action)
        return await self.post(
            f"/api/v1/employees/{employee_id}/timesheet",
            json_data={"action": action, **(timesheet_data or {})},
        )

    # ── HIS Plan ───────────────────────────────────────────────────────

    async def get_his_plan(self, employee_id: str) -> dict[str, Any]:
        """
        Retrieve health-insurance / medical plan details.

        ``GET /api/v1/employees/{employee_id}/his-plan``
        """
        logger.info("HR: get_his_plan employee=%s", employee_id)
        return await self.get(f"/api/v1/employees/{employee_id}/his-plan")

    # ── Beneficiaries ──────────────────────────────────────────────────

    async def get_beneficiaries(self, employee_id: str) -> dict[str, Any]:
        """
        Retrieve or manage beneficiary listings.

        ``GET /api/v1/employees/{employee_id}/beneficiaries``
        """
        logger.info("HR: get_beneficiaries employee=%s", employee_id)
        return await self.get(f"/api/v1/employees/{employee_id}/beneficiaries")

    async def update_beneficiaries(
        self,
        employee_id: str,
        beneficiary_data: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Update beneficiary information.

        ``PUT /api/v1/employees/{employee_id}/beneficiaries``
        """
        logger.info("HR: update_beneficiaries employee=%s", employee_id)
        return await self.put(
            f"/api/v1/employees/{employee_id}/beneficiaries",
            json_data=beneficiary_data,
        )

    # ── Associate Data (spec §2 endpoint) ──────────────────────────────

    async def get_associate_data(
        self,
        employee_id: str,
        data_type: str = "full",
    ) -> dict[str, Any]:
        """
        Retrieve associate / employee data (used by ``POST /associate_data``).

        ``GET /api/v1/employees/{employee_id}/associate-data``
        """
        logger.info("HR: get_associate_data employee=%s type=%s", employee_id, data_type)
        return await self.get(
            f"/api/v1/employees/{employee_id}/associate-data",
            params={"type": data_type},
        )
