"""
orchestrator.services.l1_service
================================
Client for the **L1 AIOps / IT-Support Agent** downstream service.

Handles spec §4 tool #8 (L1 path) and spec §5 forced-escalation.
"""

from __future__ import annotations

import logging
from typing import Any

from orchestrator.services.base_client import BaseServiceClient

logger = logging.getLogger(__name__)


class L1AIOpsClient(BaseServiceClient):
    """
    Async client for the L1 IT-support / AIOps agent.

    Expected downstream API
    -----------------------
    ``POST /api/v1/invoke``
        Body::

            {
                "query": str,
                "employee_id": str,
                "session_id": str,
                "is_escalation": bool,
                "context": {
                    "previous_tool": str | None,
                    "previous_response": str | None,
                }
            }

        Response::

            {
                "response_text": str,
                "ticket_id": str | None,
                "status": "resolved" | "escalated" | "pending",
                "metadata": {...}
            }
    """

    def __init__(self, base_url: str, **kwargs: Any) -> None:
        super().__init__(base_url, service_name="L1AIOpsService", **kwargs)

    async def invoke(
        self,
        query: str,
        employee_id: str = "",
        session_id: str = "",
        is_escalation: bool = False,
        previous_tool: str | None = None,
        previous_response: str | None = None,
    ) -> dict[str, Any]:
        """
        Invoke the L1 AIOps agent for basic IT-support or escalation.

        Returns
        -------
        dict
            Agent response with ticket information.
        """
        logger.info(
            "L1AIOps: invoke | escalation=%s employee=%s query='%s'",
            is_escalation,
            employee_id,
            query[:80],
        )
        return await self.post(
            "/api/v1/invoke",
            json_data={
                "query": query,
                "employee_id": employee_id,
                "session_id": session_id,
                "is_escalation": is_escalation,
                "context": {
                    "previous_tool": previous_tool,
                    "previous_response": previous_response,
                },
            },
        )
