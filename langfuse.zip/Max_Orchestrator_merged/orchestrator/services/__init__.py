"""
orchestrator.services
=====================
Downstream service clients used by the graph adapter nodes.

Every client is built on top of :class:`BaseServiceClient` which provides:
*  ``httpx.AsyncClient`` connection pooling.
*  Automatic structured logging with timing.
*  Langfuse span integration via the ``RequestTimer`` context var.
"""
