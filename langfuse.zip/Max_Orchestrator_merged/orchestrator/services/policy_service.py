"""
orchestrator.services.policy_service
=====================================
Client for the **Policy Search / Knowledge Base** downstream service.

Handles spec §4 tool #3: ``policy_search_manager``.
"""

from __future__ import annotations

import logging
from typing import Any

from orchestrator.services.base_client import BaseServiceClient

logger = logging.getLogger(__name__)


class PolicySearchClient(BaseServiceClient):
    """
    Async client for the Policy Search micro-service.

    Expected downstream API
    -----------------------
    ``POST /api/v1/search``
        Body: ``{"query": str, "employee_id": str, "top_k": int}``
        Response: ``{"results": [{"title": str, "content": str, "source": str, "score": float}], "metadata": {...}}``
    """

    def __init__(self, base_url: str, **kwargs: Any) -> None:
        super().__init__(base_url, service_name="PolicySearchService", **kwargs)

    async def search(
        self,
        query: str,
        employee_id: str = "",
        top_k: int = 5,
    ) -> dict[str, Any]:
        """
        Search the policy knowledge base.

        Parameters
        ----------
        query
            Natural-language policy question.
        employee_id
            Employee making the request (for access-control filtering).
        top_k
            Maximum number of results to return.

        Returns
        -------
        dict
            ``{"results": [...], "metadata": {...}}``
        """
        logger.info(
            "PolicySearch: query='%s' employee=%s top_k=%d",
            query[:80],
            employee_id,
            top_k,
        )
        return await self.post(
            "/api/v1/search",
            json_data={
                "query": query,
                "employee_id": employee_id,
                "top_k": top_k,
            },
        )
