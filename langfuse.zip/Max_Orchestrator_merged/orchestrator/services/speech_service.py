"""
orchestrator.services.speech_service
=====================================
Client for the **Speech** downstream service (STT + TTS).

Handles spec §2 endpoints: ``POST /speech_to_text`` and ``POST /text_to_speech``.
"""

from __future__ import annotations

import logging
from typing import Any

from orchestrator.services.base_client import BaseServiceClient

logger = logging.getLogger(__name__)


class SpeechServiceClient(BaseServiceClient):
    """
    Async client for the Speech (ASR / TTS) micro-service.

    Downstream API
    --------------
    **STT** – ``POST /api/v1/transcribe``
        Multipart form: ``file`` field with audio bytes.
        Response: ``{"transcript": str, "language": str, "confidence": float}``

    **TTS** – ``POST /api/v1/synthesize``
        Body: ``{"text": str, "voice": str, "format": str}``
        Response: ``{"audio_url": str, "duration_seconds": float}``
    """

    def __init__(self, base_url: str, **kwargs: Any) -> None:
        super().__init__(base_url, service_name="SpeechService", **kwargs)

    async def transcribe(
        self,
        audio_data: bytes,
        filename: str = "audio.wav",
        language: str = "en",
    ) -> dict[str, Any]:
        """
        Convert speech audio to text (STT).
        """
        logger.info(
            "Speech: transcribe file=%s size=%d lang=%s",
            filename,
            len(audio_data),
            language,
        )
        # Multipart upload – bypass the JSON-centric _request method.
        import httpx

        client = await self._get_client()
        resp = await client.post(
            "/api/v1/transcribe",
            files={"file": (filename, audio_data)},
            data={"language": language},
        )
        resp.raise_for_status()
        return resp.json()

    async def synthesize(
        self,
        text: str,
        voice: str = "default",
        audio_format: str = "mp3",
    ) -> dict[str, Any]:
        """
        Convert text to speech (TTS).
        """
        logger.info("Speech: synthesize text_len=%d voice=%s", len(text), voice)
        return await self.post(
            "/api/v1/synthesize",
            json_data={"text": text, "voice": voice, "format": audio_format},
        )
