"""
orchestrator.services.device_service
=====================================
Client for the **Device Registry** downstream service.

Handles spec §2 endpoints: ``GET /get_device`` and ``POST /device_info``.
"""

from __future__ import annotations

import logging
from typing import Any

from orchestrator.services.base_client import BaseServiceClient

logger = logging.getLogger(__name__)


class DeviceRegistryClient(BaseServiceClient):
    """Async client for the device / app-metadata registry."""

    def __init__(self, base_url: str, **kwargs: Any) -> None:
        super().__init__(base_url, service_name="DeviceRegistryService", **kwargs)

    async def get_device(
        self,
        device_id: str = "",
        session_id: str = "",
    ) -> dict[str, Any]:
        """
        Retrieve device / app metadata.

        ``GET /api/v1/devices``
        """
        logger.info("Device: get device_id=%s session=%s", device_id, session_id)
        return await self.get(
            "/api/v1/devices",
            params={"device_id": device_id, "session_id": session_id},
        )

    async def update_device(
        self,
        device_data: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Update device / app metadata.

        ``POST /api/v1/devices``
        """
        logger.info("Device: update keys=%s", list(device_data.keys()))
        return await self.post("/api/v1/devices", json_data=device_data)
