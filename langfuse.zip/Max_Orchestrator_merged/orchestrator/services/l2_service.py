"""
orchestrator.services.l2_service
================================
Client for the **L2 Application-Level Classifier & Agent** downstream service.

Handles spec §4 tool #8 (L2 path) and spec §5 child classification logic.

Two-step flow
-------------
1. **Classify** – call the child L2 classifier to identify the specific
   application (SAP, ServiceNow, CRM, etc.).
2. **Invoke** – send the classified request to the appropriate L2 sub-agent.
"""

from __future__ import annotations

import logging
from typing import Any

from orchestrator.services.base_client import BaseServiceClient

logger = logging.getLogger(__name__)


class L2ClassifierClient(BaseServiceClient):
    """
    Async client for the L2 child classifier and L2 agent invocation.

    Expected downstream API
    -----------------------

    **Classify** – ``POST /api/v1/classify``::

        Request:  {"query": str, "employee_id": str}
        Response: {
            "application": str,          # e.g. "SAP", "ServiceNow"
            "confidence": float,
            "sub_category": str | None,
            "metadata": {...}
        }

    **Invoke** – ``POST /api/v1/invoke``::

        Request: {
            "query": str,
            "employee_id": str,
            "session_id": str,
            "classification": {
                "application": str,
                "sub_category": str | None
            }
        }
        Response: {
            "response_text": str,
            "ticket_id": str | None,
            "status": "resolved" | "needs_info" | "escalated",
            "metadata": {...}
        }
    """

    def __init__(self, base_url: str, **kwargs: Any) -> None:
        super().__init__(base_url, service_name="L2ClassifierService", **kwargs)

    async def classify(
        self,
        query: str,
        employee_id: str = "",
    ) -> dict[str, Any]:
        """
        Run the child L2 classifier to identify the target application.

        Returns
        -------
        dict
            ``{"application": str, "confidence": float, ...}``
        """
        logger.info(
            "L2Classifier: classify | employee=%s query='%s'",
            employee_id,
            query[:80],
        )
        return await self.post(
            "/api/v1/classify",
            json_data={"query": query, "employee_id": employee_id},
        )

    async def invoke(
        self,
        query: str,
        employee_id: str = "",
        session_id: str = "",
        classification: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Invoke the L2 application-support agent with classification context.

        Returns
        -------
        dict
            Agent response with resolution or escalation information.
        """
        logger.info(
            "L2Agent: invoke | app=%s employee=%s query='%s'",
            (classification or {}).get("application", "unknown"),
            employee_id,
            query[:80],
        )
        return await self.post(
            "/api/v1/invoke",
            json_data={
                "query": query,
                "employee_id": employee_id,
                "session_id": session_id,
                "classification": classification or {},
            },
        )
