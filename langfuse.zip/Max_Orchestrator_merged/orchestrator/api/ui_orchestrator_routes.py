"""
orchestrator.api.ui_orchestrator_routes
=======================================
FastAPI router for the Max Orchestrator UI edge.

This module **replaces** the previous ``create_react_agent`` initialisation
in ``POST /intent-handler`` with the deterministic ``StateGraph`` from
``orchestrator.graph``.

Key changes from the legacy implementation
------------------------------------------
1. No ``create_react_agent``.  The compiled ``StateGraph`` is built per-request
   with a Postgres checkpointer injected.
2. No Redis flags for routing state.  All cross-turn state lives in the
   ``OrchestratorState`` and is persisted via the LangGraph Postgres
   checkpointer.
3. The UXB session cookie and SM headers are parsed identically to the legacy
   code and injected into the initial graph state.
4. All auxiliary endpoints (``/health``, ``/login``, ``/associate_data``, etc.)
   call real downstream services via the clients in ``orchestrator.services``.
5. Every operation is timed via ``RequestTimer`` and optionally traced to
   a self-hosted **Langfuse** instance.

Observability
-------------
*  Per-request ``RequestTimer`` is stored in a ``ContextVar`` so every node
   and service client can log timings without passing state.
*  A Langfuse ``CallbackHandler`` is attached to the graph invocation config
   if ``LANGFUSE_ENABLED=true``.
*  The response ``metadata.timing`` object contains a full breakdown of
   every operation with duration and LLM call counts.
"""

from __future__ import annotations

import json
import logging
import re
import time
import uuid
from contextlib import asynccontextmanager
from typing import Any, Optional

from fastapi import APIRouter, Cookie, Header, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from pydantic import BaseModel, Field

from orchestrator.config import get_config
from orchestrator.graph import build_orchestrator_graph, close_all_service_clients
from orchestrator.observability import (
    RequestTimer,
    get_langfuse_callback_handler,
    get_request_timer,
    set_request_timer,
    shutdown_langfuse,
)
from orchestrator.router import intent_index
from orchestrator.services.device_service import DeviceRegistryClient
from orchestrator.services.feedback_service import FeedbackServiceClient
from orchestrator.services.hr_service import HRServiceClient
from orchestrator.services.icap_service import ICAPScannerClient
from orchestrator.services.speech_service import SpeechServiceClient
from orchestrator.state import OrchestratorState, SatisfactionState

logger = logging.getLogger(__name__)

router = APIRouter()


# ═══════════════════════════════════════════════════════════════════════════
#  AUXILIARY SERVICE CLIENT SINGLETONS (for non-graph endpoints)
# ═══════════════════════════════════════════════════════════════════════════

_speech_client: Optional[SpeechServiceClient] = None
_device_client: Optional[DeviceRegistryClient] = None
_icap_client: Optional[ICAPScannerClient] = None
_feedback_client: Optional[FeedbackServiceClient] = None
_hr_client: Optional[HRServiceClient] = None


def _init_aux_clients() -> None:
    """Initialise auxiliary service clients from config."""
    global _speech_client, _device_client, _icap_client, _feedback_client, _hr_client
    cfg = get_config().services
    _speech_client = SpeechServiceClient(cfg.speech_service_url)
    _device_client = DeviceRegistryClient(cfg.device_registry_url)
    _icap_client = ICAPScannerClient(cfg.icap_scanner_url)
    _feedback_client = FeedbackServiceClient(cfg.feedback_service_url)
    _hr_client = HRServiceClient(cfg.hr_service_url)


async def _close_aux_clients() -> None:
    """Close all auxiliary service clients."""
    for client in (_speech_client, _device_client, _icap_client, _feedback_client, _hr_client):
        if client is not None:
            await client.close()


# ═══════════════════════════════════════════════════════════════════════════
#  APPLICATION LIFESPAN (intent index warm-up + service init)
# ═══════════════════════════════════════════════════════════════════════════


@asynccontextmanager
async def orchestrator_lifespan(app: Any):
    """
    FastAPI lifespan handler.

    Startup:
    *  Builds the semantic intent index so the first request doesn't pay
       the cold-start embedding cost.
    *  Initialises auxiliary service clients.
    *  Logs Langfuse status.

    Shutdown:
    *  Gracefully closes all downstream service clients.
    *  Flushes and shuts down the Langfuse client.

    Wire this into your FastAPI app::

        from orchestrator.api.ui_orchestrator_routes import orchestrator_lifespan
        app = FastAPI(lifespan=orchestrator_lifespan)
    """
    cfg = get_config()

    # ── Startup ─────────────────────────────────────────────────────────
    logger.info("Lifespan: building semantic intent index …")
    await intent_index.build()
    logger.info("Lifespan: intent index ready.")

    _init_aux_clients()
    logger.info("Lifespan: auxiliary service clients initialised.")

    if cfg.langfuse.enabled:
        logger.info(
            "Lifespan: Langfuse ENABLED → host=%s project=%s",
            cfg.langfuse.host,
            cfg.langfuse.project_name,
        )
    else:
        logger.info("Lifespan: Langfuse DISABLED (set LANGFUSE_ENABLED=true to activate).")

    yield

    # ── Shutdown ─────────────────────────────────────────────────────────
    logger.info("Lifespan: shutting down orchestrator …")
    await close_all_service_clients()
    await _close_aux_clients()
    shutdown_langfuse()
    logger.info("Lifespan: shutdown complete.")


# ═══════════════════════════════════════════════════════════════════════════
#  INPUT VALIDATION UTILITIES
# ═══════════════════════════════════════════════════════════════════════════

# Regex for detecting URLs in user prompts (spec §1: URL checks).
_URL_PATTERN = re.compile(
    r"https?://[^\s<>\"']+|www\.[^\s<>\"']+",
    re.IGNORECASE,
)

# Disallowed URL domains (security policy).
_BLOCKED_DOMAINS: set[str] = {
    "example.com",
    # Extend with actual blocked domains per your security policy.
}


def _validate_prompt_urls(prompt: str) -> None:
    """
    Check URLs in the prompt against the blocklist (spec §1: URL checks).

    Raises ``HTTPException(400)`` if a blocked URL is found.
    """
    cfg = get_config().features
    if not cfg.input_url_validation_enabled:
        return

    urls = _URL_PATTERN.findall(prompt)
    for url in urls:
        for domain in _BLOCKED_DOMAINS:
            if domain in url.lower():
                raise HTTPException(
                    status_code=400,
                    detail=f"URLs from '{domain}' are not permitted.",
                )


def _sanitise_prompt(prompt: str) -> str:
    """
    Apply format manipulation / normalisation to the raw prompt (spec §1).

    *  Strip leading / trailing whitespace.
    *  Collapse multiple whitespace runs.
    *  Remove null bytes and control characters.
    """
    # Remove null bytes and ASCII control chars (except newline / tab).
    prompt = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", prompt)
    # Collapse whitespace.
    prompt = re.sub(r"[ \t]+", " ", prompt)
    return prompt.strip()


# ═══════════════════════════════════════════════════════════════════════════
#  REQUEST / RESPONSE MODELS
# ═══════════════════════════════════════════════════════════════════════════


class IntentHandlerRequest(BaseModel):
    """JSON body for ``POST /intent-handler``."""

    prompt: str = Field(
        ...,
        description="User prompt – hard limit 500 chars (spec §3).",
    )
    attachments: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Optional file attachment metadata.",
    )
    l2_satisfaction_response: Optional[str] = Field(
        default=None,
        description=(
            "If the user is responding to an L2 satisfaction quick-reply, "
            "this field carries their selection."
        ),
    )


class IntentHandlerResponse(BaseModel):
    """Standardised JSON envelope returned by ``POST /intent-handler``."""

    response: list[dict[str, Any]]
    metadata: dict[str, Any]


# ═══════════════════════════════════════════════════════════════════════════
#  CHECKPOINTER FACTORY
# ═══════════════════════════════════════════════════════════════════════════


async def _get_checkpointer() -> AsyncPostgresSaver:
    """
    Return an async Postgres checkpointer for LangGraph state persistence.

    Reads the connection string from the centralised config.
    In production, this should be a connection-pooled singleton managed by
    the application lifespan.
    """
    cfg = get_config().postgres
    checkpointer = AsyncPostgresSaver.from_conn_string(cfg.connection_string)
    await checkpointer.setup()
    return checkpointer


# ═══════════════════════════════════════════════════════════════════════════
#  POST /intent-handler
# ═══════════════════════════════════════════════════════════════════════════


@router.post(
    "/intent-handler",
    response_model=IntentHandlerResponse,
    summary="Main UI query / intent handler",
    description=(
        "Accepts a user prompt (and optional attachments), routes it through "
        "the deterministic StateGraph, and returns a typed UI block envelope."
    ),
)
async def intent_handler(
    body: IntentHandlerRequest,
    request: Request,
    sm_useron: str = Header("", alias="SM_USERON"),
    sm_serversessionid: str = Header("", alias="SM_SERVERSESSIONID"),
    uxb_session: Optional[str] = Cookie(None, alias="UXB_SESSION"),
) -> JSONResponse:
    """
    Replacement for the legacy ReAct-based ``/intent-handler``.

    Flow
    ----
    1. Parse SM headers + UXB cookie (identical to legacy).
    2. Validate and sanitise the prompt.
    3. Build the initial ``OrchestratorState``.
    4. Invoke the compiled ``StateGraph`` with a Postgres checkpointer.
    5. Extract the formatter's response envelope from ``last_response``.
    6. Return the JSON envelope to the UI with timing metadata.
    """
    cfg = get_config()
    correlation_id = str(uuid.uuid4())

    # ── 0. Request Timer + Langfuse trace ───────────────────────────────
    timer = RequestTimer(correlation_id=correlation_id)
    set_request_timer(timer)
    timer.start_trace(
        name="intent-handler",
        user_id=sm_useron,
        session_id=sm_serversessionid,
    )

    # ── 1. Header / cookie extraction (spec §3, step 1) ────────────────
    employee_id = sm_useron or ""
    session_id = sm_serversessionid or str(uuid.uuid4())
    thread_id = f"ORCH{session_id}"  # spec §3, step 3

    logger.info(
        "intent-handler: START | employee=%s session=%s cid=%s prompt_len=%d",
        employee_id,
        session_id,
        correlation_id[:12],
        len(body.prompt),
    )

    # ── 2. Prompt validation (spec §3, step 2 + spec §1) ──────────────
    with timer.time_operation("input_validation"):
        prompt_max = cfg.features.prompt_max_length

        if not body.prompt or not body.prompt.strip():
            raise HTTPException(status_code=400, detail="Prompt must not be empty.")

        if len(body.prompt) > prompt_max:
            raise HTTPException(
                status_code=400,
                detail=f"Prompt exceeds {prompt_max} character limit.",
            )

        # URL validation (spec §1).
        _validate_prompt_urls(body.prompt)

        # Format manipulation / sanitisation (spec §1).
        clean_prompt = _sanitise_prompt(body.prompt)

    # ── 3. Handle L2 satisfaction response ──────────────────────────────
    l2_satisfaction_update = SatisfactionState.NONE
    if body.l2_satisfaction_response:
        if body.l2_satisfaction_response.lower() in ("yes", "yes, resolved", "resolved"):
            l2_satisfaction_update = SatisfactionState.SATISFIED
        else:
            l2_satisfaction_update = SatisfactionState.UNSATISFIED

    # ── 4. Build initial state ──────────────────────────────────────────
    initial_state: dict[str, Any] = {
        "messages": [HumanMessage(content=clean_prompt)],
        "session_id": session_id,
        "employee_id": employee_id,
        "correlation_id": correlation_id,
        "attachments": body.attachments,
        "uxb_session_cookie": uxb_session,
        "l2_satisfaction": l2_satisfaction_update.value,
    }

    # ── 5. Invoke the graph ─────────────────────────────────────────────
    config: dict[str, Any] = {
        "configurable": {
            "thread_id": thread_id,
        },
    }

    # Attach Langfuse callback handler if enabled.
    langfuse_handler = get_langfuse_callback_handler(
        trace_id=correlation_id,
        session_id=session_id,
        user_id=employee_id,
    )
    if langfuse_handler is not None:
        config["callbacks"] = [langfuse_handler]

    try:
        with timer.time_operation("checkpointer_init"):
            checkpointer = await _get_checkpointer()

        with timer.time_operation("graph_build_and_compile"):
            compiled_graph = build_orchestrator_graph(checkpointer=checkpointer)

        with timer.time_operation("graph_invoke"):
            result = await compiled_graph.ainvoke(initial_state, config=config)

    except HTTPException:
        raise
    except Exception:
        logger.exception("intent-handler: graph execution failed.")
        timer.end_trace(output={"error": "graph_execution_failed"})
        raise HTTPException(
            status_code=500,
            detail="An internal error occurred while processing your request.",
        )

    # ── 6. Extract the response envelope ────────────────────────────────
    with timer.time_operation("response_extraction"):
        raw_envelope = result.get("last_response", "")

        try:
            envelope = json.loads(raw_envelope) if isinstance(raw_envelope, str) else raw_envelope
        except (json.JSONDecodeError, TypeError):
            envelope = {
                "response": [{"type": "text", "content": str(raw_envelope)}],
                "metadata": {},
            }

    # Inject final timing into metadata.
    timing_summary = timer.summary()

    if "metadata" in envelope:
        envelope["metadata"]["processing_time_ms"] = round(timer.total_elapsed_ms(), 1)
        envelope["metadata"]["timing"] = timing_summary
    else:
        envelope["metadata"] = {
            "processing_time_ms": round(timer.total_elapsed_ms(), 1),
            "timing": timing_summary,
        }

    logger.info(
        "intent-handler: DONE | %.0f ms | routed_to=%s | llm_calls=%d | service_calls=%d",
        timer.total_elapsed_ms(),
        envelope.get("metadata", {}).get("routed_to", "unknown"),
        timing_summary.get("llm_calls", 0),
        timing_summary.get("service_calls", 0),
    )

    timer.end_trace(
        output={
            "routed_to": envelope.get("metadata", {}).get("routed_to", "unknown"),
            "total_ms": round(timer.total_elapsed_ms(), 1),
        },
    )

    return JSONResponse(content=envelope)


# ═══════════════════════════════════════════════════════════════════════════
#  AUXILIARY ENDPOINTS  (full implementations with downstream service calls)
# ═══════════════════════════════════════════════════════════════════════════


@router.get("/health", summary="Health check")
async def health() -> dict[str, str]:
    """Returns orchestrator health status and version."""
    return {"status": "ok", "service": "max-orchestrator", "version": "2.0.0"}


@router.get("/login", summary="Login / session route")
async def login(request: Request) -> JSONResponse:
    """
    Login / session validation endpoint.

    In production this delegates to the SSO / SiteMinder agent to validate
    the session and return user identity tokens.
    """
    timer = RequestTimer(correlation_id=str(uuid.uuid4()))
    set_request_timer(timer)

    sm_useron = request.headers.get("SM_USERON", "")
    sm_session = request.headers.get("SM_SERVERSESSIONID", "")

    if sm_useron and sm_session:
        logger.info("Login: session valid for employee=%s", sm_useron)
        return JSONResponse(
            content={
                "status": "authenticated",
                "employee_id": sm_useron,
                "session_id": sm_session,
            }
        )

    logger.info("Login: no valid session – login required.")
    return JSONResponse(
        content={"status": "login_required"},
        status_code=401,
    )


@router.post("/associate_data", summary="Employee / associate data")
async def associate_data(request: Request) -> JSONResponse:
    """
    Retrieve employee / associate data from the HR service.
    """
    timer = RequestTimer(correlation_id=str(uuid.uuid4()))
    set_request_timer(timer)

    body = await request.json()
    employee_id = body.get("employee_id", "")

    if not employee_id:
        raise HTTPException(status_code=400, detail="employee_id is required.")

    try:
        with timer.time_operation("service_call_hr_associate_data", service="hr"):
            result = await _hr_client.get_associate_data(  # type: ignore[union-attr]
                employee_id=employee_id,
                data_type=body.get("data_type", "full"),
            )
        return JSONResponse(content={"status": "ok", "data": result})
    except Exception as exc:
        logger.error("associate_data: error: %s", exc)
        return JSONResponse(
            content={"status": "error", "detail": str(exc)},
            status_code=502,
        )


@router.post("/speech_to_text", summary="Speech transcription")
async def speech_to_text(file: UploadFile) -> JSONResponse:
    """
    Transcribe an audio file to text via the Speech service.
    """
    timer = RequestTimer(correlation_id=str(uuid.uuid4()))
    set_request_timer(timer)

    audio_data = await file.read()
    filename = file.filename or "audio.wav"

    logger.info("speech_to_text: file=%s size=%d", filename, len(audio_data))

    try:
        with timer.time_operation("service_call_speech_stt", service="speech"):
            result = await _speech_client.transcribe(  # type: ignore[union-attr]
                audio_data=audio_data,
                filename=filename,
            )
        return JSONResponse(content={"status": "ok", **result})
    except Exception as exc:
        logger.error("speech_to_text: error: %s", exc)
        return JSONResponse(
            content={"status": "error", "detail": str(exc)},
            status_code=502,
        )


@router.post("/text_to_speech", summary="Speech synthesis")
async def text_to_speech(request: Request) -> JSONResponse:
    """
    Synthesize text into speech via the Speech service.
    """
    timer = RequestTimer(correlation_id=str(uuid.uuid4()))
    set_request_timer(timer)

    body = await request.json()
    text = body.get("text", "")

    if not text:
        raise HTTPException(status_code=400, detail="text is required.")

    try:
        with timer.time_operation("service_call_speech_tts", service="speech"):
            result = await _speech_client.synthesize(  # type: ignore[union-attr]
                text=text,
                voice=body.get("voice", "default"),
                audio_format=body.get("format", "mp3"),
            )
        return JSONResponse(content={"status": "ok", **result})
    except Exception as exc:
        logger.error("text_to_speech: error: %s", exc)
        return JSONResponse(
            content={"status": "error", "detail": str(exc)},
            status_code=502,
        )


@router.post("/feedback", summary="Feedback persistence")
async def feedback(request: Request) -> JSONResponse:
    """
    Persist user feedback via the Feedback service.
    """
    timer = RequestTimer(correlation_id=str(uuid.uuid4()))
    set_request_timer(timer)

    body = await request.json()
    logger.info("Feedback received: %s", body)

    try:
        with timer.time_operation("service_call_feedback", service="feedback"):
            result = await _feedback_client.submit_feedback(body)  # type: ignore[union-attr]
        return JSONResponse(content={"status": "ok", **result})
    except Exception as exc:
        logger.error("feedback: error: %s", exc)
        # Feedback failures should not block the user.
        return JSONResponse(content={"status": "accepted_with_warning", "detail": str(exc)})


@router.get("/get_device", summary="Device / app metadata retrieval")
async def get_device(request: Request) -> JSONResponse:
    """
    Retrieve device / app metadata from the Device Registry service.
    """
    timer = RequestTimer(correlation_id=str(uuid.uuid4()))
    set_request_timer(timer)

    device_id = request.query_params.get("device_id", "")
    session_id = request.query_params.get("session_id", "")

    try:
        with timer.time_operation("service_call_device_get", service="device"):
            result = await _device_client.get_device(  # type: ignore[union-attr]
                device_id=device_id,
                session_id=session_id,
            )
        return JSONResponse(content={"status": "ok", "device": result})
    except Exception as exc:
        logger.error("get_device: error: %s", exc)
        return JSONResponse(
            content={"status": "error", "detail": str(exc)},
            status_code=502,
        )


@router.post("/device_info", summary="Device / app metadata update")
async def device_info(request: Request) -> JSONResponse:
    """
    Update device / app metadata in the Device Registry service.
    """
    timer = RequestTimer(correlation_id=str(uuid.uuid4()))
    set_request_timer(timer)

    body = await request.json()

    try:
        with timer.time_operation("service_call_device_update", service="device"):
            result = await _device_client.update_device(body)  # type: ignore[union-attr]
        return JSONResponse(content={"status": "ok", **result})
    except Exception as exc:
        logger.error("device_info: error: %s", exc)
        return JSONResponse(
            content={"status": "error", "detail": str(exc)},
            status_code=502,
        )


@router.post("/file-scan", summary="ICAP file scanning")
async def file_scan(file: UploadFile) -> JSONResponse:
    """
    Scan an uploaded file for malware / policy violations via ICAP.
    """
    timer = RequestTimer(correlation_id=str(uuid.uuid4()))
    set_request_timer(timer)

    file_data = await file.read()
    filename = file.filename or "upload"
    content_type = file.content_type or "application/octet-stream"

    logger.info("file-scan: file=%s size=%d type=%s", filename, len(file_data), content_type)

    try:
        with timer.time_operation("service_call_icap_scan", service="icap"):
            result = await _icap_client.scan_file(  # type: ignore[union-attr]
                file_data=file_data,
                filename=filename,
                content_type=content_type,
            )
        return JSONResponse(content={"status": "ok", **result})
    except Exception as exc:
        logger.error("file-scan: error: %s", exc)
        return JSONResponse(
            content={"status": "error", "detail": str(exc)},
            status_code=502,
        )
