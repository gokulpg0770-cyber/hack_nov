"""
Max Orchestrator – Application Entry Point
===========================================

Mounts all orchestrator routes under the ``/app-insti`` prefix as described
in the spec (§2 note).

Usage
-----
::

    uvicorn Max_Orchestrator_merged.orchestrator.main:app --reload --port 8000

Environment
-----------
Copy ``.env.example`` to ``.env`` and fill in the values for your
environment.  Key variables:

*  ``LANGFUSE_ENABLED`` – set to ``true`` to enable self-hosted tracing.
*  ``PG_CONNECTION_STRING`` – Postgres DSN for LangGraph checkpointer.
*  ``AZURE_OPENAI_*`` – Azure OpenAI credentials and deployment names.
*  ``*_URL`` – Base URLs for each downstream micro-service.
"""

from __future__ import annotations

import logging

from fastapi import FastAPI

from orchestrator.api.ui_orchestrator_routes import orchestrator_lifespan, router
from orchestrator.config import get_config

# ── Logging ─────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
)

# Log config summary at import time.
_cfg = get_config()
_logger = logging.getLogger(__name__)
_logger.info(
    "Config loaded: langfuse=%s pg_pool=%d features.prompt_max=%d",
    _cfg.langfuse.enabled,
    _cfg.postgres.pool_size,
    _cfg.features.prompt_max_length,
)

# ── FastAPI App ─────────────────────────────────────────────────────────────
app = FastAPI(
    title="Max Orchestrator v2",
    version="2.0.0",
    description=(
        "Deterministic StateGraph orchestrator with semantic routing. "
        "Replaces the legacy ReAct agent loop."
    ),
    lifespan=orchestrator_lifespan,
)

# Mount all routes under the deployment prefix (spec §2).
app.include_router(router, prefix="/app-insti")
