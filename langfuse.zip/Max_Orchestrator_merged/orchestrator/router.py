"""
orchestrator.router
===================
**Semantic Router Node** – the first node executed on every turn.

Architecture
------------
1.  **Embed** the user prompt via a shared embedding model.
2.  **Compare** the embedding against a pre-computed intent index using
    cosine similarity.
3.  If the best-match confidence ≥ ``CONFIDENCE_THRESHOLD`` (default 0.85),
    route deterministically – *no LLM call*.
4.  If below threshold, fall back to a **structured-output LLM call** that
    returns a ``RouteDecision`` JSON, guaranteeing parseable output.

This design gives sub-50 ms routing for the ~90 % of queries that match a
known intent, and reserves LLM latency only for ambiguous / novel prompts.

Intent Index
------------
The intent index is a list of ``IntentAnchor`` objects, each carrying:
*  a natural-language exemplar sentence
*  its pre-computed embedding vector
*  the ``RouteCategory`` it maps to
*  an optional ``sub_category`` (e.g. L2 child classifier label)

The index is loaded once at process start and kept in memory.  It can be
refreshed at runtime via ``reload_intent_index()``.

Timing & Observability
----------------------
Every embedding call, LLM call, and similarity computation is measured
via the request-scoped ``RequestTimer`` and (optionally) mirrored to
Langfuse spans.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any, Optional, Sequence

import numpy as np
from langchain_core.messages import HumanMessage
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from pydantic import BaseModel, Field

from orchestrator.config import get_config
from orchestrator.observability import get_request_timer
from orchestrator.state import (
    FollowUpDecision,
    GraphState,
    RouteCategory,
    RouteDecision,
)

logger = logging.getLogger(__name__)

# ── Configuration (read from centralised config) ───────────────────────────
# These module-level constants are kept for backward-compatibility and
# fast access; they are initialised from ``get_config()`` on first use.


def _confidence_threshold() -> float:
    return get_config().features.router_confidence_threshold


# ── Intent Anchor ───────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class IntentAnchor:
    """A single intent exemplar with its pre-computed embedding."""

    exemplar: str
    category: RouteCategory
    sub_category: Optional[str] = None
    embedding: np.ndarray = field(default_factory=lambda: np.array([]))


# ── Default Intent Catalogue ───────────────────────────────────────────────
# Production deployments should load this from a versioned JSON / DB table.
# These exemplars mirror the 10 legacy tools in spec §4.

_RAW_INTENT_CATALOGUE: list[dict[str, Any]] = [
    # ── Policy ──────────────────────────────────────────────────────────
    {"exemplar": "What is the company policy on remote work?", "category": RouteCategory.POLICY},
    {"exemplar": "Show me the HR policy for parental leave", "category": RouteCategory.POLICY},
    {"exemplar": "Where can I find the travel reimbursement policy?", "category": RouteCategory.POLICY},
    {"exemplar": "What are the guidelines for expense reporting?", "category": RouteCategory.POLICY},
    {"exemplar": "Is there a dress code policy?", "category": RouteCategory.POLICY},
    {"exemplar": "What is the SOP for onboarding new employees?", "category": RouteCategory.POLICY},
    {"exemplar": "Standard operating procedure for data access requests", "category": RouteCategory.POLICY},

    # ── L1 Support ──────────────────────────────────────────────────────
    {"exemplar": "I need help with my laptop, it won't turn on", "category": RouteCategory.L1_SUPPORT},
    {"exemplar": "My VPN connection keeps dropping", "category": RouteCategory.L1_SUPPORT},
    {"exemplar": "I can't access my email account", "category": RouteCategory.L1_SUPPORT},
    {"exemplar": "Please reset my password", "category": RouteCategory.L1_SUPPORT},
    {"exemplar": "My monitor is flickering, can you help?", "category": RouteCategory.L1_SUPPORT},
    {"exemplar": "I need a new software license installed", "category": RouteCategory.L1_SUPPORT},

    # ── L2 Application ─────────────────────────────────────────────────
    {"exemplar": "The SAP application is throwing an error when I submit expenses", "category": RouteCategory.L2_APPLICATION},
    {"exemplar": "ServiceNow ticket creation is failing with a 500 error", "category": RouteCategory.L2_APPLICATION},
    {"exemplar": "The CRM dashboard is not loading data correctly", "category": RouteCategory.L2_APPLICATION},
    {"exemplar": "I'm getting a database connection timeout in the reporting tool", "category": RouteCategory.L2_APPLICATION},
    {"exemplar": "Application performance is degraded for the billing module", "category": RouteCategory.L2_APPLICATION},

    # ── Clarification ──────────────────────────────────────────────────
    {"exemplar": "What do you mean?", "category": RouteCategory.CLARIFICATION},
    {"exemplar": "Can you explain that in more detail?", "category": RouteCategory.CLARIFICATION},
    {"exemplar": "I don't understand, could you rephrase?", "category": RouteCategory.CLARIFICATION},
    {"exemplar": "Tell me more about that", "category": RouteCategory.CLARIFICATION},

    # ── Self Info ──────────────────────────────────────────────────────
    {"exemplar": "What is my employee ID?", "category": RouteCategory.SELF_INFO},
    {"exemplar": "Show me my profile information", "category": RouteCategory.SELF_INFO},
    {"exemplar": "What department am I in?", "category": RouteCategory.SELF_INFO},
    {"exemplar": "Who is my manager?", "category": RouteCategory.SELF_INFO},

    # ── Leave ──────────────────────────────────────────────────────────
    {"exemplar": "I want to apply for leave next Friday", "category": RouteCategory.LEAVE},
    {"exemplar": "Cancel my leave request for October", "category": RouteCategory.LEAVE},
    {"exemplar": "Submit a sick leave for yesterday", "category": RouteCategory.LEAVE},
    {"exemplar": "Apply for vacation from Dec 20 to Dec 31", "category": RouteCategory.LEAVE},

    # ── Timesheet ──────────────────────────────────────────────────────
    {"exemplar": "Submit my timesheet for this week", "category": RouteCategory.TIMESHEET},
    {"exemplar": "I need to correct my timesheet entry for Monday", "category": RouteCategory.TIMESHEET},
    {"exemplar": "How do I fill in my timesheet?", "category": RouteCategory.TIMESHEET},

    # ── Leave Balance ──────────────────────────────────────────────────
    {"exemplar": "How many vacation days do I have left?", "category": RouteCategory.LEAVE_BALANCE},
    {"exemplar": "Show my leave balance", "category": RouteCategory.LEAVE_BALANCE},
    {"exemplar": "What is my remaining PTO?", "category": RouteCategory.LEAVE_BALANCE},

    # ── HIS Plan ───────────────────────────────────────────────────────
    {"exemplar": "Show my health insurance plan details", "category": RouteCategory.HIS_PLAN},
    {"exemplar": "What is my current medical coverage?", "category": RouteCategory.HIS_PLAN},
    {"exemplar": "I want to see my HIS plan", "category": RouteCategory.HIS_PLAN},

    # ── Beneficiaries ──────────────────────────────────────────────────
    {"exemplar": "Who are my listed beneficiaries?", "category": RouteCategory.BENEFICIARIES},
    {"exemplar": "I need to update my beneficiary information", "category": RouteCategory.BENEFICIARIES},
    {"exemplar": "Show my beneficiaries list", "category": RouteCategory.BENEFICIARIES},

    # ── Escalation ─────────────────────────────────────────────────────
    {"exemplar": "I'm not satisfied with the resolution, escalate this", "category": RouteCategory.ESCALATION},
    {"exemplar": "This answer is wrong, I want to talk to a human", "category": RouteCategory.ESCALATION},
    {"exemplar": "Escalate my ticket, the issue is still not resolved", "category": RouteCategory.ESCALATION},
    {"exemplar": "The previous solution did not work, please escalate", "category": RouteCategory.ESCALATION},
]


# ── Embedding Utilities ────────────────────────────────────────────────────

@lru_cache(maxsize=1)
def _get_embedding_model() -> AzureOpenAIEmbeddings:
    """Singleton embedding model – lazily initialised, cached for the process."""
    cfg = get_config().azure_openai
    return AzureOpenAIEmbeddings(
        model=cfg.embedding_deployment,
        # Azure credentials are expected via env vars:
        # AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, OPENAI_API_VERSION
    )


@lru_cache(maxsize=1)
def _get_fallback_llm() -> AzureChatOpenAI:
    """Singleton cheap LLM for structured-output routing fallback."""
    cfg = get_config().azure_openai
    return AzureChatOpenAI(
        azure_deployment=cfg.fallback_llm_deployment,
        temperature=cfg.fallback_llm_temperature,
        max_tokens=cfg.fallback_llm_max_tokens,
    )


def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity between two vectors.  Expects 1-D arrays."""
    dot = np.dot(a, b)
    norm = np.linalg.norm(a) * np.linalg.norm(b)
    if norm == 0.0:
        return 0.0
    return float(dot / norm)


# ── Intent Index ────────────────────────────────────────────────────────────

class IntentIndex:
    """
    In-memory index of intent anchors with pre-computed embeddings.

    Thread-safe for reads after ``build()`` completes.
    """

    def __init__(self) -> None:
        self._anchors: list[IntentAnchor] = []
        self._is_built: bool = False

    @property
    def is_built(self) -> bool:
        return self._is_built

    # ── Build / Reload ──────────────────────────────────────────────────

    async def build(
        self,
        raw_catalogue: list[dict[str, Any]] | None = None,
    ) -> None:
        """
        Embed every exemplar and store the resulting ``IntentAnchor`` objects.

        Parameters
        ----------
        raw_catalogue
            List of dicts with keys ``exemplar``, ``category``,
            and optionally ``sub_category``.  Defaults to the built-in
            catalogue.
        """
        catalogue = raw_catalogue or _RAW_INTENT_CATALOGUE
        model = _get_embedding_model()
        timer = get_request_timer()

        exemplars = [entry["exemplar"] for entry in catalogue]
        logger.info("Intent index: embedding %d exemplars …", len(exemplars))

        with timer.time_operation("embed_intent_catalogue", count=len(exemplars)):
            t0 = time.perf_counter()
            vectors = await model.aembed_documents(exemplars)
            elapsed = time.perf_counter() - t0

        logger.info("Intent index: embedded in %.1f ms", elapsed * 1000)

        anchors: list[IntentAnchor] = []
        for entry, vec in zip(catalogue, vectors, strict=True):
            anchors.append(
                IntentAnchor(
                    exemplar=entry["exemplar"],
                    category=entry["category"],
                    sub_category=entry.get("sub_category"),
                    embedding=np.asarray(vec, dtype=np.float32),
                )
            )

        # Atomic swap – safe for concurrent readers.
        self._anchors = anchors
        self._is_built = True
        logger.info("Intent index: %d anchors ready.", len(anchors))

    # ── Query ───────────────────────────────────────────────────────────

    async def query(
        self,
        prompt_text: str,
        top_k: int = 3,
    ) -> list[tuple[IntentAnchor, float]]:
        """
        Return the *top_k* closest anchors with their similarity scores.

        Parameters
        ----------
        prompt_text
            Raw user prompt.
        top_k
            Number of results to return.

        Returns
        -------
        list[tuple[IntentAnchor, float]]
            Sorted descending by cosine similarity.
        """
        if not self._is_built:
            raise RuntimeError(
                "IntentIndex has not been built.  Call `await index.build()` "
                "at application startup."
            )

        model = _get_embedding_model()
        timer = get_request_timer()

        with timer.time_operation("embed_user_prompt"):
            prompt_vec = np.asarray(
                await model.aembed_query(prompt_text),
                dtype=np.float32,
            )

        with timer.time_operation("cosine_similarity_search", index_size=len(self._anchors)):
            scored: list[tuple[IntentAnchor, float]] = []
            for anchor in self._anchors:
                sim = _cosine_similarity(prompt_vec, anchor.embedding)
                scored.append((anchor, sim))

            scored.sort(key=lambda x: x[1], reverse=True)

        return scored[:top_k]


# Module-level singleton – initialised at startup via ``build()``.
intent_index = IntentIndex()


# ── Structured-Output Fallback Schema ───────────────────────────────────────

class LLMRouteResponse(BaseModel):
    """Schema for the structured-output LLM fallback."""

    category: RouteCategory = Field(
        description="The routing category for this user query."
    )
    sub_category: Optional[str] = Field(
        default=None,
        description="Optional sub-category for finer-grained routing.",
    )
    confidence: float = Field(
        ge=0.0,
        le=1.0,
        description="Model's self-assessed confidence in this classification.",
    )
    reasoning: str = Field(
        default="",
        description="Brief explanation of why this route was chosen.",
    )


_FALLBACK_SYSTEM_PROMPT = """\
You are a query router for an enterprise IT and HR assistant called Max.
Given the user's message and conversation history, classify the user's intent
into exactly one of the following categories:

{categories}

Respond ONLY with the structured JSON output.  Do NOT add conversational text.

Rules:
- "policy" = any question about company policies, guidelines, SOPs, or rules.
- "l1_support" = hardware, network, connectivity, password resets, basic IT help.
- "l2_application" = errors, bugs, or issues within specific enterprise applications.
- "clarification" = the user is asking the assistant to clarify its own previous response.
- "self_info" = the user wants their own employee profile data.
- "leave" = applying for, cancelling, or modifying leave requests.
- "timesheet" = anything related to time-tracking and timesheet submission.
- "leave_balance" = checking remaining PTO / vacation / sick days.
- "his_plan" = health insurance or medical plan queries.
- "beneficiaries" = beneficiary listing or updates.
- "escalation" = explicit dissatisfaction and request to escalate.
- "unknown" = none of the above categories match.
"""


async def _llm_fallback_route(
    prompt_text: str,
    history: Sequence[Any] | None = None,
) -> RouteDecision:
    """
    Use a fast, cheap LLM with structured output to classify the prompt.

    This is called **only** when the semantic similarity score is below
    the confidence threshold.

    LLM calls: **1** (structured-output classification).
    """
    llm = _get_fallback_llm()
    structured_llm = llm.with_structured_output(LLMRouteResponse)
    timer = get_request_timer()

    categories_str = "\n".join(f"- {c.value}" for c in RouteCategory)
    system_msg = _FALLBACK_SYSTEM_PROMPT.format(categories=categories_str)

    messages: list[Any] = [{"role": "system", "content": system_msg}]

    # Inject last N turns for context (cap at 6 to keep token cost low).
    if history:
        for msg in list(history)[-6:]:
            if isinstance(msg, HumanMessage):
                messages.append({"role": "user", "content": msg.content})
            else:
                messages.append({"role": "assistant", "content": str(getattr(msg, "content", ""))})

    messages.append({"role": "user", "content": prompt_text})

    logger.info("Router: LLM fallback invoked for ambiguous prompt.")

    with timer.time_operation("llm_fallback_route_classification"):
        t0 = time.perf_counter()
        result: LLMRouteResponse = await structured_llm.ainvoke(messages)  # type: ignore[assignment]
        elapsed = time.perf_counter() - t0

    logger.info(
        "Router: LLM fallback completed in %.0f ms → %s (%.2f)",
        elapsed * 1000,
        result.category,
        result.confidence,
    )

    return RouteDecision(
        category=result.category,
        confidence=result.confidence,
        sub_category=result.sub_category,
        reasoning=result.reasoning,
    )


# ── Follow-Up / Deviation Classifier ───────────────────────────────────────

class FollowUpClassification(BaseModel):
    """Structured output for follow-up vs deviation detection (spec §5)."""
    decision: FollowUpDecision
    reasoning: str = ""


_FOLLOWUP_SYSTEM_PROMPT = """\
You are analysing whether the latest user message is:
- "follow_up": a continuation of the previous conversation topic.
- "deviation": the user is changing the subject entirely.
- "new_query": this is the first message or there is no prior context.

Previous assistant response (if any):
{last_response}

Previous topic / tool:
{last_used_tool}

Respond ONLY with structured JSON output.
"""


async def _classify_follow_up(
    prompt_text: str,
    last_response: str | None,
    last_used_tool: str | None,
) -> FollowUpDecision:
    """
    Classify whether the current turn is a follow-up, deviation, or new query.

    LLM calls: **0** if no prior context, **1** otherwise.
    """
    if not last_response and not last_used_tool:
        return FollowUpDecision.NEW_QUERY

    llm = _get_fallback_llm()
    structured_llm = llm.with_structured_output(FollowUpClassification)
    timer = get_request_timer()

    system_msg = _FOLLOWUP_SYSTEM_PROMPT.format(
        last_response=last_response or "(none)",
        last_used_tool=last_used_tool or "(none)",
    )

    messages = [
        {"role": "system", "content": system_msg},
        {"role": "user", "content": prompt_text},
    ]

    with timer.time_operation("llm_followup_classification"):
        result: FollowUpClassification = await structured_llm.ainvoke(messages)  # type: ignore[assignment]

    logger.info("Follow-up classifier: %s (%s)", result.decision, result.reasoning)
    return result.decision


# ── Main Router Node ────────────────────────────────────────────────────────

async def semantic_router_node(state: dict) -> dict:
    """
    LangGraph node – **the first node in the graph**.

    Steps
    -----
    1. Extract the latest user message from ``state["messages"]``.
    2. Classify follow-up vs. deviation.
    3. Embed the prompt and query the intent index.
    4. If top-1 similarity ≥ threshold → deterministic route.
    5. Else → LLM structured-output fallback.
    6. Write ``current_route`` and ``follow_up_status`` back into state.

    LLM calls
    ---------
    *  **Best case (semantic match):** 0–1 (0 if new query, 1 for follow-up classification).
    *  **Worst case (LLM fallback):** 1–2 (follow-up classification + route classification).
    *  **Embedding calls:** Always 1 (prompt embedding for similarity search).

    Returns
    -------
    dict
        Partial state update (LangGraph merges it).
    """
    timer = get_request_timer()
    messages = state.get("messages", [])

    if not messages:
        logger.warning("Router: no messages in state – returning UNKNOWN.")
        return {
            "current_route": RouteDecision(
                category=RouteCategory.UNKNOWN,
                confidence=0.0,
                reasoning="No user message found.",
            ),
        }

    # Extract latest human message text.
    latest_msg = messages[-1]
    prompt_text: str = (
        latest_msg.content
        if isinstance(latest_msg, HumanMessage)
        else str(getattr(latest_msg, "content", ""))
    )

    # ── Follow-up / deviation ───────────────────────────────────────────
    with timer.time_operation("router_followup_classification"):
        follow_up_status = await _classify_follow_up(
            prompt_text=prompt_text,
            last_response=state.get("last_response"),
            last_used_tool=state.get("last_used_tool"),
        )

    # Handle forced escalation (spec §5: L2 unsatisfied → L1).
    if state.get("l2_satisfaction") == "unsatisfied":
        logger.info("Router: forced escalation due to L2 unsatisfied flag.")
        return {
            "current_route": RouteDecision(
                category=RouteCategory.ESCALATION,
                confidence=1.0,
                reasoning="L2 satisfaction marked unsatisfied – forced escalation to L1.",
            ),
            "follow_up_status": follow_up_status,
            "l2_satisfaction": "none",  # Reset after escalation
        }

    # ── Semantic similarity ─────────────────────────────────────────────
    with timer.time_operation("router_semantic_search"):
        top_matches = await intent_index.query(prompt_text, top_k=3)

    best_anchor, best_score = top_matches[0] if top_matches else (None, 0.0)
    threshold = _confidence_threshold()

    if best_anchor and best_score >= threshold:
        logger.info(
            "Router: semantic match → %s (%.3f) [%s]",
            best_anchor.category.value,
            best_score,
            best_anchor.exemplar[:60],
        )
        route_decision = RouteDecision(
            category=best_anchor.category,
            confidence=best_score,
            sub_category=best_anchor.sub_category,
            reasoning=f"Semantic match to: '{best_anchor.exemplar}' (score={best_score:.3f})",
        )
    else:
        logger.info(
            "Router: best semantic score %.3f < threshold %.2f – falling back to LLM.",
            best_score if best_anchor else 0.0,
            threshold,
        )
        route_decision = await _llm_fallback_route(
            prompt_text=prompt_text,
            history=messages[:-1] if len(messages) > 1 else None,
        )

    # ── Update primary query on new queries ─────────────────────────────
    updates: dict[str, Any] = {
        "current_route": route_decision,
        "follow_up_status": follow_up_status,
    }
    if follow_up_status == FollowUpDecision.NEW_QUERY:
        updates["primary_query"] = prompt_text

    return updates
