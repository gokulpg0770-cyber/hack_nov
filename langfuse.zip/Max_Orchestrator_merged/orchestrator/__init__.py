# Max Orchestrator – Deterministic StateGraph Orchestration Layer
# Copyright 2026.  All rights reserved.
"""
Orchestration layer entry-point.

Modules
-------
config        – Centralised environment-variable configuration.
observability – Per-request timing (``RequestTimer``) + Langfuse integration.
state         – Canonical ``OrchestratorState`` shared by every node.
router        – Semantic-embedding classifier + structured-output LLM fallback.
graph         – Hub-and-spoke ``StateGraph`` wiring (router → adapters → formatter).
services/     – Async HTTP clients for every downstream micro-service.
"""

__version__ = "2.0.0"
