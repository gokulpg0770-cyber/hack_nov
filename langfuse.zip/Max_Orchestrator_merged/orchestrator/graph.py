"""
orchestrator.graph
==================
Hub-and-Spoke ``StateGraph`` wiring.

Topology
--------
::

    START
      │
      ▼
    semantic_router
      │
      ├── (policy)          → policy_adapter_node
      ├── (l1_support)      → l1_adapter_node
      ├── (l2_application)  → l2_adapter_node
      ├── (clarification)   → clarification_adapter_node
      ├── (self_info)       → direct_capability_node
      ├── (leave)           → direct_capability_node
      ├── (timesheet)       → direct_capability_node
      ├── (leave_balance)   → direct_capability_node
      ├── (his_plan)        → direct_capability_node
      ├── (beneficiaries)   → direct_capability_node
      ├── (escalation)      → l1_adapter_node          (forced escalation)
      └── (unknown)         → clarification_adapter_node
      │
      ▼  (all paths)
    ui_formatter_node
      │
      ▼
    END

Every adapter / capability node writes ``UIBlock`` objects into
``state["pending_ui_blocks"]`` and sets ``last_used_tool`` / ``last_response``.
The ``ui_formatter_node`` normalises them into the final response envelope
(spec §7).

Adapter nodes call real downstream services via the clients defined in
``orchestrator.services``.  Timing for every service call is recorded via
the request-scoped ``RequestTimer`` stored in a ``ContextVar``.
"""

from __future__ import annotations

import json
import logging
import re
import time
from typing import Any, Literal, Optional

from langchain_core.messages import AIMessage
from langgraph.graph import END, START, StateGraph

from orchestrator.config import get_config
from orchestrator.observability import get_request_timer
from orchestrator.router import semantic_router_node
from orchestrator.services.base_client import ServiceError
from orchestrator.services.hr_service import HRServiceClient
from orchestrator.services.l1_service import L1AIOpsClient
from orchestrator.services.l2_service import L2ClassifierClient
from orchestrator.services.policy_service import PolicySearchClient
from orchestrator.state import (
    FollowUpDecision,
    GraphState,
    RouteCategory,
    RouteDecision,
    SatisfactionState,
    UIBlock,
    UIBlockType,
)

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
#  SERVICE CLIENT SINGLETONS
# ═══════════════════════════════════════════════════════════════════════════
#
# Lazily created on first access.  In production these would be initialised
# once inside the FastAPI lifespan handler with connection-pooled httpx
# clients.
# ═══════════════════════════════════════════════════════════════════════════

_policy_client: Optional[PolicySearchClient] = None
_l1_client: Optional[L1AIOpsClient] = None
_l2_client: Optional[L2ClassifierClient] = None
_hr_client: Optional[HRServiceClient] = None


def _get_policy_client() -> PolicySearchClient:
    global _policy_client
    if _policy_client is None:
        cfg = get_config().services
        _policy_client = PolicySearchClient(cfg.policy_search_url)
    return _policy_client


def _get_l1_client() -> L1AIOpsClient:
    global _l1_client
    if _l1_client is None:
        cfg = get_config().services
        _l1_client = L1AIOpsClient(cfg.l1_aiops_url)
    return _l1_client


def _get_l2_client() -> L2ClassifierClient:
    global _l2_client
    if _l2_client is None:
        cfg = get_config().services
        _l2_client = L2ClassifierClient(cfg.l2_classifier_url)
    return _l2_client


def _get_hr_client() -> HRServiceClient:
    global _hr_client
    if _hr_client is None:
        cfg = get_config().services
        _hr_client = HRServiceClient(cfg.hr_service_url)
    return _hr_client


async def close_all_service_clients() -> None:
    """Gracefully close every downstream client (called at shutdown)."""
    for client in (_policy_client, _l1_client, _l2_client, _hr_client):
        if client is not None:
            await client.close()


# ═══════════════════════════════════════════════════════════════════════════
#  UTILITY
# ═══════════════════════════════════════════════════════════════════════════


def _latest_prompt(state: dict) -> str:
    """Extract the text of the latest user message from state."""
    messages = state.get("messages", [])
    if not messages:
        return ""
    latest = messages[-1]
    return str(getattr(latest, "content", ""))


def _safe_service_error_text(exc: ServiceError) -> str:
    """Produce a user-friendly error message from a service failure."""
    return (
        "I'm sorry, I encountered an issue while processing your request.  "
        f"The {exc.service} service responded with an error.  "
        "Please try again or contact support if the problem persists."
    )


# ═══════════════════════════════════════════════════════════════════════════
#  ADAPTER / CAPABILITY NODES  (full implementations with downstream calls)
# ═══════════════════════════════════════════════════════════════════════════


async def policy_adapter_node(state: dict) -> dict:
    """
    Adapter for the **policy_search_manager** downstream service.

    LLM calls: **0** (pure retrieval).
    Downstream calls: **1** → Policy Search API.

    Flow
    ----
    1. Extract prompt from state.
    2. Call the Policy Search micro-service via ``PolicySearchClient.search()``.
    3. Format results into ``UIBlock`` objects (text + references).
    """
    prompt = _latest_prompt(state)
    employee_id = state.get("employee_id", "")
    timer = get_request_timer()

    logger.info("PolicyAdapter: START | prompt='%s'", prompt[:80])

    try:
        with timer.time_operation("service_call_policy_search", service="policy"):
            client = _get_policy_client()
            result = await client.search(
                query=prompt,
                employee_id=employee_id,
                top_k=5,
            )

        # Parse response from downstream.
        results = result.get("results", [])
        if results:
            # Build text block from top results.
            text_parts: list[str] = []
            ref_blocks: list[UIBlock] = []
            for i, item in enumerate(results[:3], 1):
                title = item.get("title", f"Result {i}")
                content = item.get("content", "")
                source = item.get("source", "")
                text_parts.append(f"**{title}**\n{content}")
                ref_blocks.append(
                    UIBlock(
                        block_type=UIBlockType.REFERENCE,
                        content={"title": title, "source": source},
                    )
                )
            result_text = "\n\n---\n\n".join(text_parts)
        else:
            result_text = (
                "I wasn't able to find a specific policy matching your query.  "
                "Could you rephrase or provide more detail about which policy "
                "you're looking for?"
            )
            ref_blocks = []

        blocks: list[UIBlock] = [
            UIBlock(block_type=UIBlockType.TEXT, content=result_text),
            *ref_blocks,
        ]

    except ServiceError as exc:
        logger.error("PolicyAdapter: service error: %s", exc)
        result_text = _safe_service_error_text(exc)
        blocks = [UIBlock(block_type=UIBlockType.TEXT, content=result_text)]

    logger.info("PolicyAdapter: DONE | result_len=%d", len(result_text))

    return {
        "pending_ui_blocks": blocks,
        "last_used_tool": "policy_search_manager",
        "last_response": result_text,
        "messages": [AIMessage(content=result_text)],
    }


async def l1_adapter_node(state: dict) -> dict:
    """
    Adapter for **L1 AIOps / IT-support** routing.

    This node handles both:
    *  Direct L1 routing from the semantic router.
    *  Forced escalation when ``current_route.category == ESCALATION``.

    LLM calls: **0** at orchestrator level (L1 agent may use LLMs internally).
    Downstream calls: **1** → L1 AIOps Agent API.
    """
    prompt = _latest_prompt(state)
    route = state.get("current_route")
    is_escalation = getattr(route, "category", None) == RouteCategory.ESCALATION
    timer = get_request_timer()

    logger.info(
        "L1Adapter: START | %s | prompt='%s'",
        "ESCALATION" if is_escalation else "L1_SUPPORT",
        prompt[:80],
    )

    try:
        with timer.time_operation(
            "service_call_l1_aiops",
            service="l1_aiops",
            is_escalation=is_escalation,
        ):
            client = _get_l1_client()
            result = await client.invoke(
                query=prompt,
                employee_id=state.get("employee_id", ""),
                session_id=state.get("session_id", ""),
                is_escalation=is_escalation,
                previous_tool=state.get("last_used_tool"),
                previous_response=state.get("last_response"),
            )

        result_text = result.get("response_text", "")
        ticket_id = result.get("ticket_id")
        status = result.get("status", "pending")

        blocks: list[UIBlock] = [
            UIBlock(block_type=UIBlockType.TEXT, content=result_text),
        ]

        if ticket_id:
            blocks.append(
                UIBlock(
                    block_type=UIBlockType.CARD,
                    content={
                        "title": "Support Ticket Created",
                        "ticket_id": ticket_id,
                        "status": status,
                    },
                )
            )

        if is_escalation:
            blocks.append(
                UIBlock(
                    block_type=UIBlockType.DISCLAIMER,
                    content="Your issue has been escalated to a human agent.",
                )
            )

    except ServiceError as exc:
        logger.error("L1Adapter: service error: %s", exc)
        result_text = _safe_service_error_text(exc)
        blocks = [UIBlock(block_type=UIBlockType.TEXT, content=result_text)]

    logger.info("L1Adapter: DONE")

    return {
        "pending_ui_blocks": blocks,
        "last_used_tool": "l1_aiops_agent",
        "last_response": result_text,
        "l2_satisfaction": SatisfactionState.NONE.value,
        "messages": [AIMessage(content=result_text)],
    }


async def l2_adapter_node(state: dict) -> dict:
    """
    Adapter for **L2 Application-level** issue routing.

    Two-step flow (spec §5):
    1. If ``max_orchestrator_call`` flag is active → run the child L2 classifier.
    2. Invoke the L2 sub-agent with the classification result.
    3. Set ``l2_satisfaction`` to ``PENDING`` so the next turn can check.

    LLM calls: **0** at orchestrator level (classifier + agent may use LLMs).
    Downstream calls: **1–2** → L2 Classifier + L2 Agent.
    """
    prompt = _latest_prompt(state)
    route = state.get("current_route")
    sub_cat = getattr(route, "sub_category", None)
    timer = get_request_timer()
    cfg = get_config().features

    logger.info("L2Adapter: START | sub_category=%s | prompt='%s'", sub_cat, prompt[:80])

    classification: dict[str, Any] = {}

    try:
        # ── Step 1: L2 child classification (if enabled) ────────────────
        if cfg.max_orchestrator_call and cfg.l2_classifier_enabled:
            with timer.time_operation("service_call_l2_classify", service="l2_classifier"):
                client = _get_l2_client()
                classification = await client.classify(
                    query=prompt,
                    employee_id=state.get("employee_id", ""),
                )
            logger.info(
                "L2Adapter: classified → app=%s confidence=%.2f",
                classification.get("application", "unknown"),
                classification.get("confidence", 0.0),
            )
        else:
            logger.info("L2Adapter: L2 classifier disabled – sending to L1 fallback.")
            # Fall back to L1 if L2 classifier is disabled (spec §5).
            return await _l2_fallback_to_l1(state, prompt, timer)

        # ── Step 2: Invoke L2 agent ─────────────────────────────────────
        with timer.time_operation("service_call_l2_invoke", service="l2_agent"):
            result = await _get_l2_client().invoke(
                query=prompt,
                employee_id=state.get("employee_id", ""),
                session_id=state.get("session_id", ""),
                classification=classification,
            )

        result_text = result.get("response_text", "")
        status = result.get("status", "resolved")

        blocks: list[UIBlock] = [
            UIBlock(block_type=UIBlockType.TEXT, content=result_text),
        ]

        # Add satisfaction quick-replies so we can track L2 outcome.
        blocks.append(
            UIBlock(
                block_type=UIBlockType.QUICK_REPLIES,
                content={
                    "prompt": "Was this resolution helpful?",
                    "options": ["Yes, resolved", "No, escalate"],
                },
            )
        )

        if result.get("ticket_id"):
            blocks.append(
                UIBlock(
                    block_type=UIBlockType.CARD,
                    content={
                        "title": f"L2 Ticket – {classification.get('application', 'App')}",
                        "ticket_id": result["ticket_id"],
                        "status": status,
                    },
                )
            )

    except ServiceError as exc:
        logger.error("L2Adapter: service error – falling back to L1: %s", exc)
        return await _l2_fallback_to_l1(state, prompt, timer)

    logger.info("L2Adapter: DONE | status=%s", status)

    return {
        "pending_ui_blocks": blocks,
        "last_used_tool": "aiops_manager",
        "last_response": result_text,
        "l2_satisfaction": SatisfactionState.PENDING.value,
        "user_action_required": True,
        "messages": [AIMessage(content=result_text)],
    }


async def _l2_fallback_to_l1(state: dict, prompt: str, timer: Any) -> dict:
    """
    Fallback: send the L2 request to the L1 agent when the L2 classifier
    is disabled, unavailable, or returns low-confidence results (spec §5).
    """
    logger.info("L2→L1 Fallback: routing to L1 AIOps agent.")

    try:
        with timer.time_operation("service_call_l1_fallback", service="l1_aiops"):
            client = _get_l1_client()
            result = await client.invoke(
                query=prompt,
                employee_id=state.get("employee_id", ""),
                session_id=state.get("session_id", ""),
                is_escalation=False,
                previous_tool=state.get("last_used_tool"),
                previous_response=state.get("last_response"),
            )

        result_text = result.get("response_text", "")
        blocks: list[UIBlock] = [
            UIBlock(block_type=UIBlockType.TEXT, content=result_text),
        ]

    except ServiceError as exc:
        logger.error("L2→L1 Fallback: service error: %s", exc)
        result_text = _safe_service_error_text(exc)
        blocks = [UIBlock(block_type=UIBlockType.TEXT, content=result_text)]

    return {
        "pending_ui_blocks": blocks,
        "last_used_tool": "l1_aiops_agent",
        "last_response": result_text,
        "l2_satisfaction": SatisfactionState.NONE.value,
        "messages": [AIMessage(content=result_text)],
    }


async def clarification_adapter_node(state: dict) -> dict:
    """
    Adapter for **clarification** requests or unknown intents.

    Returns a gentle clarification prompt back to the user.

    LLM calls: **0**.
    Downstream calls: **0**.
    """
    prompt = _latest_prompt(state)
    route = state.get("current_route")
    category = getattr(route, "category", RouteCategory.UNKNOWN)
    timer = get_request_timer()

    logger.info("ClarificationAdapter: category=%s", category)

    with timer.time_operation("clarification_response_build"):
        if category == RouteCategory.UNKNOWN:
            result_text = (
                "I wasn't able to determine your intent clearly.  "
                "Could you please rephrase or provide more detail about "
                "what you need help with?"
            )
        else:
            result_text = (
                "I'd like to help, but I need a bit more context.  "
                "Could you elaborate on your question?"
            )

    blocks = [UIBlock(block_type=UIBlockType.TEXT, content=result_text)]

    return {
        "pending_ui_blocks": blocks,
        "last_used_tool": "clarification_manager",
        "last_response": result_text,
        "user_action_required": True,
        "messages": [AIMessage(content=result_text)],
    }


async def direct_capability_node(state: dict) -> dict:
    """
    Adapter for **direct / legacy capabilities**: self_info, leave, timesheet,
    leave_balance, his_plan, beneficiaries.

    Routes internally to the correct HR-service method based on
    ``state["current_route"].category``.

    LLM calls: **0**.
    Downstream calls: **1** → HR Service API (specific endpoint per capability).
    """
    prompt = _latest_prompt(state)
    route = state.get("current_route")
    category: RouteCategory = getattr(route, "category", RouteCategory.UNKNOWN)
    employee_id = state.get("employee_id", "")
    timer = get_request_timer()

    # Map categories to the legacy tool names from spec §4.
    _TOOL_MAP: dict[RouteCategory, str] = {
        RouteCategory.SELF_INFO: "self_info_manager",
        RouteCategory.LEAVE: "leave_manager",
        RouteCategory.TIMESHEET: "timesheet_manager",
        RouteCategory.LEAVE_BALANCE: "employee_leave_balance",
        RouteCategory.HIS_PLAN: "his_plan_manager",
        RouteCategory.BENEFICIARIES: "beneficiaries_manager",
    }

    tool_name = _TOOL_MAP.get(category, "unknown_capability")
    logger.info("DirectCapability: START | %s | prompt='%s'", tool_name, prompt[:80])

    hr = _get_hr_client()
    result_text = ""
    blocks: list[UIBlock] = []

    try:
        if category == RouteCategory.SELF_INFO:
            with timer.time_operation("service_call_hr_self_info", service="hr"):
                data = await hr.get_self_info(employee_id)
            result_text = _format_self_info(data)

        elif category == RouteCategory.LEAVE_BALANCE:
            with timer.time_operation("service_call_hr_leave_balance", service="hr"):
                data = await hr.get_leave_balance(employee_id)
            result_text = _format_leave_balance(data)

        elif category == RouteCategory.LEAVE:
            with timer.time_operation("service_call_hr_leave", service="hr"):
                data = await hr.manage_leave(
                    employee_id=employee_id,
                    action="query",
                    leave_data={"prompt": prompt},
                )
            result_text = _format_leave_response(data)

        elif category == RouteCategory.TIMESHEET:
            with timer.time_operation("service_call_hr_timesheet", service="hr"):
                data = await hr.manage_timesheet(
                    employee_id=employee_id,
                    action="query",
                    timesheet_data={"prompt": prompt},
                )
            result_text = _format_timesheet_response(data)

        elif category == RouteCategory.HIS_PLAN:
            with timer.time_operation("service_call_hr_his_plan", service="hr"):
                data = await hr.get_his_plan(employee_id)
            result_text = _format_his_plan(data)

        elif category == RouteCategory.BENEFICIARIES:
            with timer.time_operation("service_call_hr_beneficiaries", service="hr"):
                data = await hr.get_beneficiaries(employee_id)
            result_text = _format_beneficiaries(data)

        else:
            result_text = (
                "I'm not sure how to handle that request.  "
                "Could you clarify what you need?"
            )

        blocks = [UIBlock(block_type=UIBlockType.TEXT, content=result_text)]

    except ServiceError as exc:
        logger.error("DirectCapability[%s]: service error: %s", tool_name, exc)
        result_text = _safe_service_error_text(exc)
        blocks = [UIBlock(block_type=UIBlockType.TEXT, content=result_text)]

    logger.info("DirectCapability: DONE | %s", tool_name)

    return {
        "pending_ui_blocks": blocks,
        "last_used_tool": tool_name,
        "last_response": result_text,
        "messages": [AIMessage(content=result_text)],
    }


# ── HR Data Formatters ──────────────────────────────────────────────────────
# These convert raw JSON from the HR service into user-friendly markdown.


def _format_self_info(data: dict[str, Any]) -> str:
    profile = data.get("profile", data)
    parts = ["Here is your profile information:\n"]
    for key in ("name", "employee_id", "department", "title", "manager", "email", "location"):
        val = profile.get(key)
        if val:
            label = key.replace("_", " ").title()
            parts.append(f"- **{label}:** {val}")
    return "\n".join(parts) if len(parts) > 1 else str(data)


def _format_leave_balance(data: dict[str, Any]) -> str:
    balances = data.get("balances", data)
    if isinstance(balances, list):
        parts = ["Your current leave balances:\n"]
        for b in balances:
            leave_type = b.get("type", "Leave")
            remaining = b.get("remaining", "N/A")
            total = b.get("total", "N/A")
            parts.append(f"- **{leave_type}:** {remaining} / {total} days remaining")
        return "\n".join(parts)
    return str(data)


def _format_leave_response(data: dict[str, Any]) -> str:
    status = data.get("status", "processed")
    message = data.get("message", "")
    if message:
        return message
    return f"Your leave request has been {status}."


def _format_timesheet_response(data: dict[str, Any]) -> str:
    status = data.get("status", "processed")
    message = data.get("message", "")
    if message:
        return message
    return f"Your timesheet action has been {status}."


def _format_his_plan(data: dict[str, Any]) -> str:
    plan = data.get("plan", data)
    parts = ["Your health insurance plan details:\n"]
    for key in ("plan_name", "provider", "coverage_type", "deductible", "copay", "effective_date"):
        val = plan.get(key)
        if val:
            label = key.replace("_", " ").title()
            parts.append(f"- **{label}:** {val}")
    return "\n".join(parts) if len(parts) > 1 else str(data)


def _format_beneficiaries(data: dict[str, Any]) -> str:
    beneficiaries = data.get("beneficiaries", data)
    if isinstance(beneficiaries, list):
        parts = ["Your listed beneficiaries:\n"]
        for i, b in enumerate(beneficiaries, 1):
            name = b.get("name", f"Beneficiary {i}")
            relationship = b.get("relationship", "")
            percentage = b.get("percentage", "")
            detail = f"- **{name}**"
            if relationship:
                detail += f" ({relationship})"
            if percentage:
                detail += f" – {percentage}%"
            parts.append(detail)
        return "\n".join(parts)
    return str(data)


# ═══════════════════════════════════════════════════════════════════════════
#  DEVIATION HANDLER NODE
# ═══════════════════════════════════════════════════════════════════════════


async def deviation_handler_node(state: dict) -> dict:
    """
    Intercepts deviation cases (spec §5).

    If the router classified the turn as a ``DEVIATION``, this node emits a
    quick-reply block asking the user whether to abandon the previous query
    before proceeding.

    LLM calls: **0**.
    Downstream calls: **0**.
    """
    prompt = _latest_prompt(state)
    previous_tool = state.get("last_used_tool", "unknown")
    timer = get_request_timer()

    with timer.time_operation("deviation_handler"):
        result_text = (
            "It looks like you're switching topics.  "
            f"Your previous query was being handled by **{previous_tool}**.  "
            "Would you like to continue with the previous topic or start a new one?"
        )

        blocks = [
            UIBlock(block_type=UIBlockType.TEXT, content=result_text),
            UIBlock(
                block_type=UIBlockType.QUICK_REPLIES,
                content={
                    "prompt": "Continue or start new?",
                    "options": ["Continue previous", "Start new topic"],
                },
            ),
        ]

    return {
        "pending_ui_blocks": blocks,
        "last_response": result_text,
        "user_action_required": True,
        "messages": [AIMessage(content=result_text)],
    }


# ═══════════════════════════════════════════════════════════════════════════
#  UI FORMATTER NODE
# ═══════════════════════════════════════════════════════════════════════════

# Terminology replacements (spec §7, rule 3).
_TERMINOLOGY_REPLACEMENTS: dict[str, str] = {
    "associate": "employee",
    "team member": "employee",
    # Extend as needed per organisation glossary.
}

_TERMINOLOGY_PATTERN = re.compile(
    "|".join(re.escape(k) for k in _TERMINOLOGY_REPLACEMENTS),
    flags=re.IGNORECASE,
)


def _apply_terminology(text: str) -> str:
    """Apply terminology replacements (case-insensitive)."""
    if not _TERMINOLOGY_REPLACEMENTS:
        return text

    def _replace(match: re.Match) -> str:
        return _TERMINOLOGY_REPLACEMENTS.get(match.group(0).lower(), match.group(0))

    return _TERMINOLOGY_PATTERN.sub(_replace, text)


def _strip_is_question(text: str) -> tuple[str, bool]:
    """
    Remove the ``is_question: true/false`` convention from downstream text
    (spec §7, rule 2) and return the cleaned text plus the boolean flag.
    """
    is_question = False
    match = re.search(r"is_question:\s*(true|false)", text, re.IGNORECASE)
    if match:
        is_question = match.group(1).lower() == "true"
        text = text[: match.start()] + text[match.end() :]
        text = text.strip()
    return text, is_question


def _validate_response_security(text: str) -> str:
    """
    Basic response security validation (spec §7, rule 4).

    Strip potential prompt-injection artefacts, script tags, etc.
    Production deployments should integrate a dedicated content-safety
    scanner here.
    """
    # Remove script tags and on* event handlers.
    text = re.sub(r"<script[^>]*>.*?</script>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"\bon\w+\s*=", "", text, flags=re.IGNORECASE)
    return text


async def ui_formatter_node(state: dict) -> dict:
    """
    Terminal node – assembles the final UI response envelope (spec §7).

    Responsibilities
    ----------------
    1. Iterates ``pending_ui_blocks`` and normalises every text block:
       *  Parses serialised JSON strings into dicts.
       *  Strips ``is_question`` convention.
       *  Applies terminology replacements.
       *  Validates response security.
    2. Merges any pending attachment / satisfaction states.
    3. Builds the ``response`` array and ``metadata`` dict.
    4. Injects timing summary from the ``RequestTimer``.

    LLM calls: **0**.
    Downstream calls: **0**.
    """
    raw_blocks: list[UIBlock] = state.get("pending_ui_blocks", [])
    user_action_required: bool = state.get("user_action_required", False)
    timer = get_request_timer()

    with timer.time_operation("ui_formatter_normalisation"):
        normalised_blocks: list[dict[str, Any]] = []

        for block in raw_blocks:
            content = block.content if isinstance(block, UIBlock) else block.get("content", "")  # type: ignore[union-attr]
            block_type = block.block_type if isinstance(block, UIBlock) else block.get("block_type", "text")  # type: ignore[union-attr]

            # ── Parse serialised JSON ───────────────────────────────────
            if isinstance(content, str):
                try:
                    content = json.loads(content)
                except (json.JSONDecodeError, TypeError):
                    pass

            # ── Text-specific normalisation ─────────────────────────────
            if isinstance(content, str):
                content, is_q = _strip_is_question(content)
                if is_q:
                    user_action_required = True
                content = _apply_terminology(content)
                content = _validate_response_security(content)

            block_type_value = block_type.value if isinstance(block_type, UIBlockType) else str(block_type)
            block_meta = block.metadata if isinstance(block, UIBlock) else block.get("metadata", {})  # type: ignore[union-attr]

            normalised_blocks.append(
                {
                    "type": block_type_value,
                    "content": content,
                    "metadata": block_meta,
                }
            )

    # ── Build response envelope ─────────────────────────────────────────
    timing_summary = timer.summary()

    response_envelope: dict[str, Any] = {
        "response": normalised_blocks,
        "metadata": {
            "feedback_enabled": True,
            "ui_thread_id": state.get("session_id", ""),
            "attachment_state": {
                "has_attachments": bool(state.get("attachments")),
                "count": len(state.get("attachments", [])),
            },
            "user_action_required": user_action_required,
            "correlation_id": state.get("correlation_id", ""),
            "routed_to": (
                state["current_route"].category.value
                if state.get("current_route") and hasattr(state["current_route"], "category")
                else "unknown"
            ),
            "timing": timing_summary,
        },
    }

    return {
        "user_action_required": user_action_required,
        # Stash the final envelope in last_response for the API layer.
        "last_response": json.dumps(response_envelope, default=str),
        # Clear the accumulator so the next turn starts fresh.
        "pending_ui_blocks": [],
    }


# ═══════════════════════════════════════════════════════════════════════════
#  CONDITIONAL EDGES
# ═══════════════════════════════════════════════════════════════════════════


def _route_after_semantic_router(
    state: dict,
) -> Literal[
    "deviation_handler",
    "policy_adapter",
    "l1_adapter",
    "l2_adapter",
    "clarification_adapter",
    "direct_capability",
]:
    """
    Conditional edge: dispatches to the correct spoke based on the route
    decision written by ``semantic_router_node``.
    """
    # ── Handle deviations first (spec §5) ───────────────────────────────
    follow_up = state.get("follow_up_status")
    if follow_up == FollowUpDecision.DEVIATION or follow_up == "deviation":
        return "deviation_handler"

    route = state.get("current_route")
    if route is None:
        return "clarification_adapter"

    category = route.category if hasattr(route, "category") else route.get("category")
    if isinstance(category, str):
        try:
            category = RouteCategory(category)
        except ValueError:
            category = RouteCategory.UNKNOWN

    _ROUTE_TABLE: dict[RouteCategory, str] = {
        RouteCategory.POLICY: "policy_adapter",
        RouteCategory.L1_SUPPORT: "l1_adapter",
        RouteCategory.L2_APPLICATION: "l2_adapter",
        RouteCategory.CLARIFICATION: "clarification_adapter",
        RouteCategory.SELF_INFO: "direct_capability",
        RouteCategory.LEAVE: "direct_capability",
        RouteCategory.TIMESHEET: "direct_capability",
        RouteCategory.LEAVE_BALANCE: "direct_capability",
        RouteCategory.HIS_PLAN: "direct_capability",
        RouteCategory.BENEFICIARIES: "direct_capability",
        RouteCategory.ESCALATION: "l1_adapter",
        RouteCategory.UNKNOWN: "clarification_adapter",
    }

    return _ROUTE_TABLE.get(category, "clarification_adapter")  # type: ignore[return-value]


# ═══════════════════════════════════════════════════════════════════════════
#  GRAPH ASSEMBLY
# ═══════════════════════════════════════════════════════════════════════════


def build_orchestrator_graph(checkpointer: Any = None) -> Any:
    """
    Construct and compile the deterministic orchestrator ``StateGraph``.

    Parameters
    ----------
    checkpointer
        Optional LangGraph checkpointer (e.g. ``AsyncPostgresSaver``).
        When provided, the graph persists state across turns.

    Returns a **compiled** graph ready for ``.ainvoke()`` / ``.astream()``.

    Usage
    -----
    ::

        from orchestrator.graph import build_orchestrator_graph
        graph = build_orchestrator_graph(checkpointer=my_checkpointer)
        result = await graph.ainvoke(initial_state, config=config)
    """
    graph = StateGraph(GraphState)

    # ── Add nodes ───────────────────────────────────────────────────────
    graph.add_node("semantic_router", semantic_router_node)
    graph.add_node("deviation_handler", deviation_handler_node)
    graph.add_node("policy_adapter", policy_adapter_node)
    graph.add_node("l1_adapter", l1_adapter_node)
    graph.add_node("l2_adapter", l2_adapter_node)
    graph.add_node("clarification_adapter", clarification_adapter_node)
    graph.add_node("direct_capability", direct_capability_node)
    graph.add_node("ui_formatter", ui_formatter_node)

    # ── Entry edge ──────────────────────────────────────────────────────
    graph.add_edge(START, "semantic_router")

    # ── Conditional fan-out from router ─────────────────────────────────
    graph.add_conditional_edges(
        "semantic_router",
        _route_after_semantic_router,
        {
            "deviation_handler": "deviation_handler",
            "policy_adapter": "policy_adapter",
            "l1_adapter": "l1_adapter",
            "l2_adapter": "l2_adapter",
            "clarification_adapter": "clarification_adapter",
            "direct_capability": "direct_capability",
        },
    )

    # ── All spoke nodes converge on UI formatter ────────────────────────
    for spoke in (
        "deviation_handler",
        "policy_adapter",
        "l1_adapter",
        "l2_adapter",
        "clarification_adapter",
        "direct_capability",
    ):
        graph.add_edge(spoke, "ui_formatter")

    # ── UI formatter → END ──────────────────────────────────────────────
    graph.add_edge("ui_formatter", END)

    return graph.compile(checkpointer=checkpointer)
