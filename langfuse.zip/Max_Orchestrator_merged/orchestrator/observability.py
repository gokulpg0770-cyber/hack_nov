"""
orchestrator.observability
==========================
Request-scoped timing, structured logging, and **Langfuse** integration.

Design
------
*  ``RequestTimer`` is the per-request timing accumulator.  It is stored in a
   ``ContextVar`` so that every graph node and service call can access it
   without passing it through the LangGraph state (which must be serialisable).
*  Langfuse is **opt-in**.  Set ``LANGFUSE_ENABLED=true`` to activate.
   All Langfuse operations are wrapped in try/except so a connectivity blip
   never blocks the hot path.

Usage in a graph node
---------------------
::

    from orchestrator.observability import get_request_timer

    async def my_node(state: dict) -> dict:
        timer = get_request_timer()
        with timer.time_operation("downstream_call", service="policy"):
            result = await policy_client.search(...)
        ...
"""

from __future__ import annotations

import logging
import time
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any, Optional

from orchestrator.config import get_config

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════
#  LANGFUSE CLIENT LIFECYCLE
# ═══════════════════════════════════════════════════════════════════════════

_langfuse_client: Any = None


def get_langfuse() -> Any:
    """Lazy-initialise and return the Langfuse client singleton (or ``None``)."""
    global _langfuse_client
    cfg = get_config().langfuse

    if not cfg.enabled:
        return None

    if _langfuse_client is None:
        try:
            from langfuse import Langfuse  # type: ignore[import-untyped]

            _langfuse_client = Langfuse(
                public_key=cfg.public_key,
                secret_key=cfg.secret_key,
                host=cfg.host,
            )
            logger.info(
                "Langfuse client initialised → host=%s project=%s env=%s",
                cfg.host,
                cfg.project_name,
                cfg.environment,
            )
        except ImportError:
            logger.warning(
                "langfuse package not installed – tracing disabled.  "
                "Install with: pip install langfuse"
            )
        except Exception as exc:
            logger.warning("Failed to initialise Langfuse client: %s", exc)

    return _langfuse_client


def get_langfuse_callback_handler(
    trace_id: Optional[str] = None,
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    **kwargs: Any,
) -> Any:
    """
    Return a LangChain-compatible ``CallbackHandler`` for Langfuse.

    This is the handler you pass into LangGraph's ``config["callbacks"]``
    list so that every LLM / embedding call inside the graph is traced
    automatically.

    Returns ``None`` if Langfuse is disabled or unavailable.
    """
    cfg = get_config().langfuse
    if not cfg.enabled:
        return None

    try:
        from langfuse.callback import CallbackHandler  # type: ignore[import-untyped]

        return CallbackHandler(
            public_key=cfg.public_key,
            secret_key=cfg.secret_key,
            host=cfg.host,
            trace_id=trace_id,
            session_id=session_id,
            user_id=user_id,
            **kwargs,
        )
    except ImportError:
        return None
    except Exception as exc:
        logger.warning("Failed to create Langfuse CallbackHandler: %s", exc)
        return None


def shutdown_langfuse() -> None:
    """Flush pending events and shut down the Langfuse client."""
    global _langfuse_client
    if _langfuse_client is not None:
        try:
            _langfuse_client.flush()
            _langfuse_client.shutdown()
            logger.info("Langfuse client shut down.")
        except Exception as exc:
            logger.warning("Error shutting down Langfuse: %s", exc)
        finally:
            _langfuse_client = None


# ═══════════════════════════════════════════════════════════════════════════
#  TIMING PRIMITIVES
# ═══════════════════════════════════════════════════════════════════════════


@dataclass
class TimingLog:
    """One timing measurement within a request."""

    operation: str
    duration_ms: float
    success: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        status = "✓" if self.success else "✗"
        meta = " | ".join(f"{k}={v}" for k, v in self.metadata.items())
        return (
            f"[{status}] {self.operation}: {self.duration_ms:.1f} ms"
            + (f" | {meta}" if meta else "")
        )


class RequestTimer:
    """
    Per-request timing accumulator.

    Stores timing entries for every operation (LLM call, embedding,
    downstream HTTP, etc.) and optionally mirrors them to a Langfuse trace.
    """

    def __init__(self, correlation_id: str = "") -> None:
        self.correlation_id = correlation_id or str(uuid.uuid4())
        self.start_time = time.perf_counter()
        self.logs: list[TimingLog] = []
        self._langfuse_trace: Any = None

    # ── Langfuse trace lifecycle ────────────────────────────────────────

    def start_trace(
        self,
        name: str,
        user_id: str = "",
        session_id: str = "",
        **kwargs: Any,
    ) -> None:
        """Create a Langfuse trace for this request."""
        lf = get_langfuse()
        if lf is None:
            return
        try:
            self._langfuse_trace = lf.trace(
                id=self.correlation_id,
                name=name,
                user_id=user_id,
                session_id=session_id,
                metadata=kwargs,
            )
        except Exception as exc:
            logger.warning("Langfuse trace start failed: %s", exc)

    def end_trace(self, output: Any = None, **metadata: Any) -> None:
        """Close the Langfuse trace with a summary."""
        if self._langfuse_trace is None:
            return
        try:
            self._langfuse_trace.update(
                output=output,
                metadata={
                    "total_ms": round(self.total_elapsed_ms(), 1),
                    "operation_count": len(self.logs),
                    "llm_call_count": self.llm_call_count,
                    **metadata,
                },
            )
        except Exception as exc:
            logger.warning("Langfuse trace end failed: %s", exc)

    # ── Operation timing ────────────────────────────────────────────────

    @contextmanager
    def time_operation(self, operation: str, **metadata: Any):
        """
        Context manager that records wall-clock duration of *operation*.

        If a Langfuse trace is active, a child span is created automatically.
        """
        t0 = time.perf_counter()
        span: Any = None

        if self._langfuse_trace is not None:
            try:
                span = self._langfuse_trace.span(
                    name=operation, metadata=metadata
                )
            except Exception:
                pass

        try:
            yield
            elapsed = (time.perf_counter() - t0) * 1000
            entry = TimingLog(
                operation=operation,
                duration_ms=elapsed,
                success=True,
                metadata=metadata,
            )
            self.logs.append(entry)
            logger.info(
                "TIMING | cid=%s | %s", self.correlation_id[:12], entry
            )
            if span is not None:
                try:
                    span.end(metadata={"duration_ms": elapsed, "success": True})
                except Exception:
                    pass

        except Exception as exc:
            elapsed = (time.perf_counter() - t0) * 1000
            entry = TimingLog(
                operation=operation,
                duration_ms=elapsed,
                success=False,
                metadata={**metadata, "error": type(exc).__name__},
            )
            self.logs.append(entry)
            logger.error(
                "TIMING | cid=%s | %s", self.correlation_id[:12], entry
            )
            if span is not None:
                try:
                    span.end(
                        metadata={
                            "duration_ms": elapsed,
                            "success": False,
                            "error": str(exc),
                        }
                    )
                except Exception:
                    pass
            raise

    # ── Aggregation helpers ─────────────────────────────────────────────

    def total_elapsed_ms(self) -> float:
        return (time.perf_counter() - self.start_time) * 1000

    @property
    def llm_call_count(self) -> int:
        return sum(
            1
            for log in self.logs
            if any(
                kw in log.operation.lower()
                for kw in ("llm", "embed", "chat_completion", "structured_output")
            )
        )

    @property
    def service_call_count(self) -> int:
        return sum(
            1
            for log in self.logs
            if any(
                kw in log.operation.lower()
                for kw in ("service", "http", "downstream", "api_call")
            )
        )

    def summary(self) -> dict[str, Any]:
        """Structured summary suitable for JSON logging or API response metadata."""
        return {
            "correlation_id": self.correlation_id,
            "total_ms": round(self.total_elapsed_ms(), 1),
            "llm_calls": self.llm_call_count,
            "service_calls": self.service_call_count,
            "operations": [
                {
                    "op": log.operation,
                    "ms": round(log.duration_ms, 1),
                    "ok": log.success,
                    **log.metadata,
                }
                for log in self.logs
            ],
        }


# ═══════════════════════════════════════════════════════════════════════════
#  CONTEXT-VAR ACCESSOR (request-scoped, thread-/async-safe)
# ═══════════════════════════════════════════════════════════════════════════

_request_timer: ContextVar[Optional[RequestTimer]] = ContextVar(
    "_request_timer", default=None
)


def set_request_timer(timer: RequestTimer) -> None:
    """Pin a ``RequestTimer`` to the current async context."""
    _request_timer.set(timer)


def get_request_timer() -> RequestTimer:
    """
    Retrieve the current request's timer.

    If none has been set (e.g. during unit-testing), a throwaway timer is
    returned so callers never have to ``None``-check.
    """
    timer = _request_timer.get()
    if timer is None:
        timer = RequestTimer(correlation_id="no-request-context")
    return timer
