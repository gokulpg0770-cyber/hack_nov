"""
orchestrator.state
==================
Canonical **OrchestratorState** – a single source of truth for every node in
the deterministic StateGraph.

Design Decisions
----------------
*  ``TypedDict`` instead of a Pydantic ``BaseModel`` because LangGraph's
   ``StateGraph[S]`` expects a mapping type; Pydantic v2 models do *not*
   satisfy ``Mapping`` without an adapter.  The Pydantic models referenced
   here (``UIBlock``, ``RouteDecision``) are used as *values* inside the
   TypedDict and are validated at the node boundary.
*  **No Redis flags.**  Every cross-request datum that was previously stored
   in Redis (``last_used_tool``, ``last_response``, ``primary_query``,
   ``L2_SATISFACTION_PENDING``, pending-UI-satisfaction) is now a first-class
   field in this state.  The LangGraph Postgres checkpointer persists the
   entire state between turns, eliminating the Redis ↔ Postgres split-brain
   problem described in the spec §6.
*  ``pending_ui_blocks`` is an **append-only** ``Annotated[list, operator.add]``
   so that parallel branches can each emit blocks without clobbering each
   other.
"""

from __future__ import annotations

import operator
from enum import Enum
from typing import Annotated, Any, Literal, Optional, Sequence

from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages
from pydantic import BaseModel, Field


# ── Route Taxonomy ──────────────────────────────────────────────────────────
class RouteCategory(str, Enum):
    """Top-level routing buckets mirroring the legacy ``intelligent_router``."""

    POLICY = "policy"
    L1_SUPPORT = "l1_support"
    L2_APPLICATION = "l2_application"
    CLARIFICATION = "clarification"
    SELF_INFO = "self_info"
    LEAVE = "leave"
    TIMESHEET = "timesheet"
    LEAVE_BALANCE = "leave_balance"
    HIS_PLAN = "his_plan"
    BENEFICIARIES = "beneficiaries"
    ESCALATION = "escalation"
    UNKNOWN = "unknown"


# ── UI Block models (strict Pydantic v2) ────────────────────────────────────
class UIBlockType(str, Enum):
    TEXT = "text"
    REFERENCE = "reference"
    QUICK_REPLIES = "quick_replies"
    CARD = "card"
    DISCLAIMER = "disclaimer"


class UIBlock(BaseModel):
    """Typed UI block conforming to the response contract (spec §7)."""

    block_type: UIBlockType
    content: Any
    metadata: dict[str, Any] = Field(default_factory=dict)


class RouteDecision(BaseModel):
    """Structured output emitted by the semantic router."""

    category: RouteCategory
    confidence: float = Field(ge=0.0, le=1.0)
    sub_category: Optional[str] = None
    reasoning: str = ""


class SatisfactionState(str, Enum):
    """L2 satisfaction tracking – replaces Redis ``L2_SATISFACTION_PENDING``."""

    NONE = "none"
    PENDING = "pending"
    SATISFIED = "satisfied"
    UNSATISFIED = "unsatisfied"


class FollowUpDecision(str, Enum):
    """Follow-up / deviation classification (spec §5)."""

    FOLLOW_UP = "follow_up"
    DEVIATION = "deviation"
    NEW_QUERY = "new_query"


# ── Orchestrator State ──────────────────────────────────────────────────────
class OrchestratorState(BaseModel):
    """
    The single, canonical state object threaded through every graph node.

    LangGraph ``StateGraph`` expects a ``TypedDict``-like schema.  We expose
    ``OrchestratorState`` as a Pydantic model for validation at entry / exit
    and convert via ``.model_dump()`` where the graph infra needs a raw dict.

    All fields that were previously in Redis are marked with ``# ex-Redis``.
    """

    # ── conversation ────────────────────────────────────────────────────
    messages: Annotated[Sequence[BaseMessage], add_messages] = Field(
        default_factory=list,
        description="Full conversation history managed by LangGraph's message reducer.",
    )
    session_id: str = Field(
        ...,
        description="SM_SERVERSESSIONID – the durable session token.",
    )
    employee_id: str = Field(
        default="",
        description="Derived from SM_USERON header.",
    )
    correlation_id: str = Field(
        default="",
        description="Per-request trace / correlation ID.",
    )

    # ── routing ─────────────────────────────────────────────────────────
    current_route: Optional[RouteDecision] = Field(
        default=None,
        description="The latest routing decision from the semantic router node.",
    )
    follow_up_status: FollowUpDecision = Field(
        default=FollowUpDecision.NEW_QUERY,
        description="Whether the current turn is a follow-up, deviation, or new query.",
    )

    # ── cross-turn memory (ex-Redis) ────────────────────────────────────
    last_used_tool: Optional[str] = Field(
        default=None,
        description="Name of the last sub-graph / adapter that executed.  # ex-Redis",
    )
    last_response: Optional[str] = Field(
        default=None,
        description="Serialized last downstream response.  # ex-Redis",
    )
    primary_query: Optional[str] = Field(
        default=None,
        description="The original user question for the current thread.  # ex-Redis",
    )
    l2_satisfaction: SatisfactionState = Field(
        default=SatisfactionState.NONE,
        description="L2 satisfaction lifecycle.  # ex-Redis",
    )

    # ── UI accumulation ─────────────────────────────────────────────────
    pending_ui_blocks: Annotated[list[UIBlock], operator.add] = Field(
        default_factory=list,
        description="Append-only list of UI blocks built by adapter nodes.",
    )
    user_action_required: bool = Field(
        default=False,
        description="True when the response expects a user action (``is_question: true``).",
    )

    # ── attachment / file context ───────────────────────────────────────
    attachments: list[dict[str, Any]] = Field(
        default_factory=list,
        description="File metadata for attachments uploaded in this turn.",
    )

    # ── UXB cookie pass-through ─────────────────────────────────────────
    uxb_session_cookie: Optional[str] = Field(
        default=None,
        description="Raw UXB session cookie forwarded from the UI layer.",
    )

    class Config:
        arbitrary_types_allowed = True


# ── LangGraph-compatible TypedDict view ─────────────────────────────────────
# LangGraph StateGraph expects a TypedDict.  We generate one dynamically from
# the Pydantic model so the two never diverge.

from typing import TypedDict  # noqa: E402 – intentional late import


def _build_state_typeddict() -> type:
    """
    Programmatically build a ``TypedDict`` whose fields mirror
    ``OrchestratorState``.  This is the type passed to
    ``StateGraph[GraphState]``.
    """
    annotations: dict[str, Any] = {}
    for name, field_info in OrchestratorState.model_fields.items():
        annotations[name] = field_info.annotation
    ns: dict[str, Any] = {"__annotations__": annotations}
    return type("GraphState", (TypedDict,), ns)  # type: ignore[misc]


GraphState = _build_state_typeddict()
