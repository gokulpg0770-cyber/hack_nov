# Max Orchestrator v2 – Architecture

## 1. High-Level Overview

Max Orchestrator v2 is a **deterministic, hub-and-spoke StateGraph** that replaces the
legacy ReAct agent loop.  It serves as the unified UI/API edge for the Max enterprise
assistant, handling session management, semantic routing, downstream service
orchestration, and UI response formatting.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          Max Orchestrator v2                                │
│                                                                             │
│   ┌──────────┐    ┌───────────────┐    ┌────────────┐    ┌──────────────┐  │
│   │ FastAPI   │───▶│ StateGraph    │───▶│ Adapter    │───▶│ UI Formatter │  │
│   │ Edge      │    │ (Semantic     │    │ Nodes      │    │ (Response    │  │
│   │ Layer     │    │  Router)      │    │ (Spokes)   │    │  Envelope)   │  │
│   └──────────┘    └───────────────┘    └────────────┘    └──────────────┘  │
│        │                                      │                             │
│        │         ┌────────────────────────────┘                             │
│        │         │  Downstream Services                                     │
│        │         ▼                                                          │
│   ┌──────────────────────────────────────────────────────────────┐          │
│   │  Policy │ L1 AIOps │ L2 Classifier │ HR/HRIS │ Speech │ ... │          │
│   └──────────────────────────────────────────────────────────────┘          │
│                                                                             │
│   ┌───────────────────────────┐  ┌──────────────────────────────────┐      │
│   │  PostgreSQL               │  │  Langfuse (Self-Hosted)          │      │
│   │  (LangGraph Checkpointer) │  │  (Optional Observability)       │      │
│   └───────────────────────────┘  └──────────────────────────────────┘      │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Module Map

```
Max_Orchestrator_merged/
├── .env.example                    # All environment variables
├── requirements.txt                # Python dependencies
└── orchestrator/
    ├── __init__.py                 # Package metadata
    ├── main.py                     # FastAPI app entry point
    ├── config.py                   # Centralised env-var configuration
    ├── observability.py            # RequestTimer + Langfuse integration
    ├── state.py                    # OrchestratorState (canonical state)
    ├── router.py                   # Semantic router (embeddings + LLM fallback)
    ├── graph.py                    # StateGraph wiring + adapter nodes
    ├── api/
    │   ├── __init__.py
    │   └── ui_orchestrator_routes.py   # FastAPI endpoints
    └── services/
        ├── __init__.py
        ├── base_client.py          # Abstract async HTTP client
        ├── policy_service.py       # Policy KB search client
        ├── l1_service.py           # L1 AIOps agent client
        ├── l2_service.py           # L2 classifier + agent client
        ├── hr_service.py           # HR/HRIS API client
        ├── speech_service.py       # STT + TTS client
        ├── device_service.py       # Device registry client
        ├── icap_service.py         # ICAP file scanner client
        └── feedback_service.py     # Feedback persistence client
```

---

## 3. StateGraph Topology

```mermaid
graph TD
    START((START)) --> semantic_router

    semantic_router -->|deviation| deviation_handler
    semantic_router -->|policy| policy_adapter
    semantic_router -->|l1_support| l1_adapter
    semantic_router -->|l2_application| l2_adapter
    semantic_router -->|clarification| clarification_adapter
    semantic_router -->|self_info / leave / timesheet / leave_balance / his_plan / beneficiaries| direct_capability
    semantic_router -->|escalation| l1_adapter
    semantic_router -->|unknown| clarification_adapter

    deviation_handler --> ui_formatter
    policy_adapter --> ui_formatter
    l1_adapter --> ui_formatter
    l2_adapter --> ui_formatter
    clarification_adapter --> ui_formatter
    direct_capability --> ui_formatter

    ui_formatter --> END((END))
```

---

## 4. Core Components

### 4.1 Semantic Router (`router.py`)

The router is the **first node** executed on every turn.  It uses a
two-tier classification strategy:

| Tier | When Used | Latency | LLM Calls |
|------|-----------|---------|-----------|
| **Embedding Similarity** | Cosine score ≥ 0.85 against pre-computed intent index | ~10–50 ms | 0 |
| **LLM Structured Output** | Score < 0.85 (ambiguous / novel prompt) | ~200–800 ms | 1 |

Before routing, the router also classifies whether the turn is a
**follow-up**, **deviation**, or **new query** (spec §5).

### 4.2 State Management (`state.py`)

All cross-turn state is consolidated into a single `OrchestratorState`
Pydantic model, eliminating the Redis ↔ Postgres split-brain:

| Field | Ex-Redis? | Purpose |
|-------|-----------|---------|
| `messages` | No | LangGraph message history |
| `current_route` | No | Latest routing decision |
| `follow_up_status` | No | Follow-up / deviation / new query |
| `last_used_tool` | ✅ | Name of last adapter that ran |
| `last_response` | ✅ | Serialized last response |
| `primary_query` | ✅ | Original user question for the thread |
| `l2_satisfaction` | ✅ | L2 satisfaction lifecycle state |
| `pending_ui_blocks` | ✅ | Append-only UI block accumulator |
| `user_action_required` | ✅ | Whether user interaction is needed |

### 4.3 Adapter Nodes (`graph.py`)

Each adapter node follows the same contract:
1. Extract prompt + context from state.
2. Call the downstream service via an `httpx`-based async client.
3. Format the response into `UIBlock` objects.
4. Return a partial state update.

| Node | Downstream Service | Tools Covered |
|------|--------------------|---------------|
| `policy_adapter` | Policy Search API | `policy_search_manager` |
| `l1_adapter` | L1 AIOps Agent | `intelligent_router` (L1 path) |
| `l2_adapter` | L2 Classifier + Agent | `aiops_manager` |
| `direct_capability` | HR/HRIS API | `self_info`, `leave`, `timesheet`, `leave_balance`, `his_plan`, `beneficiaries` |
| `clarification_adapter` | (none – local) | `clarification_manager` |
| `deviation_handler` | (none – local) | (spec §5 deviation prompt) |

### 4.4 UI Formatter (`graph.py → ui_formatter_node`)

The terminal node that normalises all pending UI blocks:

1. Parses serialised JSON strings.
2. Strips the `is_question: true/false` convention.
3. Applies terminology replacements.
4. Validates response security (script tag removal, etc.).
5. Builds the response envelope with metadata + timing summary.

### 4.5 Observability (`observability.py`)

| Feature | Implementation |
|---------|----------------|
| **Per-Request Timing** | `RequestTimer` stored in a `ContextVar` – every node and service call records wall-clock duration. |
| **Langfuse Tracing** | Opt-in via `LANGFUSE_ENABLED=true`. Traces are created per-request with child spans for each operation. LLM calls are automatically traced via `CallbackHandler`. |
| **Structured Logging** | All timing entries are logged at `INFO` level with a `TIMING` prefix and correlation ID. |
| **Response Metadata** | The `metadata.timing` field in every response contains a full breakdown of operations. |

---

## 5. API Endpoints

All endpoints are prefixed with `/app-insti` in production.

| Method | Path | Purpose | Downstream Service |
|--------|------|---------|-------------------|
| `POST` | `/intent-handler` | Main query handler (graph invocation) | All (via graph) |
| `GET` | `/health` | Health check | None |
| `GET` | `/login` | Session validation | SSO / SiteMinder |
| `POST` | `/associate_data` | Employee data retrieval | HR Service |
| `POST` | `/speech_to_text` | Audio transcription | Speech Service |
| `POST` | `/text_to_speech` | Text synthesis | Speech Service |
| `POST` | `/feedback` | Feedback persistence | Feedback Service |
| `GET` | `/get_device` | Device metadata retrieval | Device Registry |
| `POST` | `/device_info` | Device metadata update | Device Registry |
| `POST` | `/file-scan` | ICAP malware scanning | ICAP Scanner |

---

## 6. Downstream Service Architecture

```mermaid
graph LR
    ORCH[Max Orchestrator] --> PS[Policy Search<br/>:8001]
    ORCH --> L1[L1 AIOps Agent<br/>:8002]
    ORCH --> L2[L2 Classifier<br/>:8003]
    ORCH --> HR[HR / HRIS<br/>:8004]
    ORCH --> SP[Speech STT/TTS<br/>:8005]
    ORCH --> DR[Device Registry<br/>:8006]
    ORCH --> IC[ICAP Scanner<br/>:8007]
    ORCH --> FB[Feedback Store<br/>:8008]
    ORCH --> SSO[SSO Service<br/>:8009]

    ORCH --> PG[(PostgreSQL<br/>Checkpointer)]
    ORCH -.->|optional| LF[Langfuse<br/>Self-Hosted]
```

All service clients extend `BaseServiceClient` which provides:
- **Connection pooling** via `httpx.AsyncClient`.
- **Retry with exponential back-off** on 429/503 responses.
- **Automatic timing** via the request-scoped `RequestTimer`.
- **Langfuse span integration** via the `ContextVar`.

---

## 7. Langfuse Integration

Langfuse is a self-hosted LLM observability platform.  The integration is
**disabled by default** and activated via environment variables:

```bash
LANGFUSE_ENABLED=true
LANGFUSE_HOST=http://your-langfuse-host:3000
LANGFUSE_PUBLIC_KEY=pk-lf-...
LANGFUSE_SECRET_KEY=sk-lf-...
```

### What gets traced

| Trace Type | Source | Automatic? |
|------------|--------|------------|
| LLM calls (route classification, follow-up detection) | `CallbackHandler` in graph config | ✅ Yes |
| Embedding calls (intent index, prompt embedding) | `CallbackHandler` in graph config | ✅ Yes |
| Service HTTP calls (policy, L1, L2, HR, etc.) | `RequestTimer` spans | ✅ Yes |
| Graph node execution (router, adapters, formatter) | `RequestTimer` spans | ✅ Yes |
| Request lifecycle (total duration, operation count) | Root trace in `intent_handler` | ✅ Yes |

### Graceful degradation

- If `langfuse` is not installed → warning log, tracing disabled.
- If Langfuse host is unreachable → warning log, tracing disabled.
- If any span creation fails → warning log, request continues normally.

---

## 8. Configuration

All configuration is centralised in `orchestrator/config.py` and read from
environment variables.  See `.env.example` for the complete list.

```mermaid
graph TD
    ENV[".env / Environment"] --> AC[AppConfig]
    AC --> LF[LangfuseConfig]
    AC --> PG[PostgresConfig]
    AC --> AZ[AzureOpenAIConfig]
    AC --> SE[ServiceEndpoints]
    AC --> FF[FeatureFlags]
```

Key feature flags:
- `MAX_ORCHESTRATOR_CALL` – enables/disables the L2 child classifier.
- `L2_CLASSIFIER_ENABLED` – secondary toggle for L2 classification.
- `ROUTER_CONFIDENCE_THRESHOLD` – cosine similarity threshold (default 0.85).
- `INPUT_URL_VALIDATION_ENABLED` – URL blocklist checking in prompts.

---

## 9. Data Flow: Request Lifecycle

```mermaid
sequenceDiagram
    participant UI as UI Client
    participant API as FastAPI Edge
    participant Timer as RequestTimer
    participant Graph as StateGraph
    participant Router as Semantic Router
    participant Adapter as Adapter Node
    participant Svc as Downstream Service
    participant Fmt as UI Formatter
    participant PG as PostgreSQL
    participant LF as Langfuse

    UI->>API: POST /intent-handler
    API->>Timer: Create timer + Langfuse trace
    API->>API: Validate + sanitise prompt
    API->>PG: Get checkpointer
    API->>Graph: .ainvoke(initial_state)
    Graph->>Router: semantic_router_node(state)
    Router->>Router: Classify follow-up/deviation
    Router->>Router: Embed prompt + cosine search
    alt Score ≥ threshold
        Router-->>Graph: Deterministic route (0 LLM calls)
    else Score < threshold
        Router->>Router: LLM structured-output fallback (1 LLM call)
        Router-->>Graph: LLM-classified route
    end
    Graph->>Adapter: Selected adapter node
    Adapter->>Svc: HTTP call to downstream service
    Svc-->>Adapter: Service response
    Adapter-->>Graph: UIBlocks + state update
    Graph->>Fmt: ui_formatter_node
    Fmt-->>Graph: Response envelope
    Graph-->>API: Final state
    API->>Timer: Collect timing summary
    API-->>LF: End trace (if enabled)
    API-->>UI: JSONResponse with timing metadata
```
