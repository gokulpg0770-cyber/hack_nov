# Max Orchestrator v2 – User Flows

This document details every user-facing flow through the orchestrator,
including the exact number of LLM calls, embedding calls, and downstream
service calls at each step.

---

## Table of Contents

1. [Flow Summary Matrix](#1-flow-summary-matrix)
2. [Policy / SOP Query](#2-policy--sop-query)
3. [L1 IT-Support Query](#3-l1-it-support-query)
4. [L2 Application Issue Query](#4-l2-application-issue-query)
5. [Leave Management](#5-leave-management)
6. [Leave Balance Check](#6-leave-balance-check)
7. [Self Info Query](#7-self-info-query)
8. [HIS Plan Query](#8-his-plan-query)
9. [Beneficiaries Query](#9-beneficiaries-query)
10. [Timesheet Management](#10-timesheet-management)
11. [Clarification / Unknown Intent](#11-clarification--unknown-intent)
12. [Deviation Detection](#12-deviation-detection)
13. [L2 Satisfaction → Escalation](#13-l2-satisfaction--escalation)
14. [Follow-Up on Previous Query](#14-follow-up-on-previous-query)
15. [Auxiliary Endpoints](#15-auxiliary-endpoints)

---

## 1. Flow Summary Matrix

| User Intent | Route Category | Embedding Calls | LLM Calls (Best) | LLM Calls (Worst) | Service Calls | Nodes Traversed |
|---|---|---|---|---|---|---|
| Policy / SOP question | `policy` | 1 | 0 | 2 | 1 | 3 |
| L1 IT support | `l1_support` | 1 | 0 | 2 | 1 | 3 |
| L2 application issue | `l2_application` | 1 | 0 | 2 | 2 | 3 |
| Leave apply/cancel/modify | `leave` | 1 | 0 | 2 | 1 | 3 |
| Leave balance check | `leave_balance` | 1 | 0 | 2 | 1 | 3 |
| Self info lookup | `self_info` | 1 | 0 | 2 | 1 | 3 |
| HIS plan details | `his_plan` | 1 | 0 | 2 | 1 | 3 |
| Beneficiaries listing | `beneficiaries` | 1 | 0 | 2 | 1 | 3 |
| Timesheet submit/correct | `timesheet` | 1 | 0 | 2 | 1 | 3 |
| Clarification request | `clarification` | 1 | 0 | 2 | 0 | 3 |
| Unknown / ambiguous | `unknown` | 1 | 1 | 2 | 0 | 3 |
| Deviation detected | `deviation` | 1 | 1 | 2 | 0 | 3 |
| Forced escalation (L2 unsat.) | `escalation` | 1 | 0 | 1 | 1 | 3 |

**Key:**
- **Embedding Calls:** Always 1 (prompt embedding for cosine similarity search).
- **LLM Calls (Best):** When the prompt matches the intent index above the 0.85 threshold AND it's a new query (no follow-up classification needed).
- **LLM Calls (Worst):** When follow-up classification + LLM fallback routing are both needed.
- **Service Calls:** HTTP calls to downstream micro-services.
- **Nodes Traversed:** Always 3: `semantic_router` → `adapter` → `ui_formatter`.

---

## 2. Policy / SOP Query

**Example prompts:**
- "What is the company policy on remote work?"
- "Show me the SOP for onboarding new employees"
- "Where can I find the travel reimbursement policy?"

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant PA as Policy Adapter
    participant PS as Policy Search Service
    participant F as UI Formatter

    U->>R: "What is the remote work policy?"
    Note over R: 1. Embed prompt (1 embedding call)
    Note over R: 2. Cosine search → POLICY (score ≥ 0.85)
    Note over R: 3. No LLM needed (deterministic route)
    R->>PA: route = POLICY
    PA->>PS: POST /api/v1/search {query, employee_id, top_k: 5}
    PS-->>PA: {results: [{title, content, source}]}
    Note over PA: Format results into TEXT + REFERENCE blocks
    PA->>F: pending_ui_blocks
    Note over F: 1. Apply terminology replacements
    Note over F: 2. Validate security
    Note over F: 3. Build response envelope
    F-->>U: {response: [{type: text}, {type: reference}], metadata: {...}}
```

### Call Breakdown (Best Case – New Query, Semantic Match)

| Operation | Type | Count |
|---|---|---|
| Prompt embedding | Embedding | 1 |
| Cosine similarity search | Local compute | 1 |
| Policy Search API call | HTTP | 1 |
| **Total LLM calls** | | **0** |
| **Total service calls** | | **1** |

### Call Breakdown (Worst Case – Follow-up, LLM Fallback)

| Operation | Type | Count |
|---|---|---|
| Follow-up classification | LLM (structured output) | 1 |
| Prompt embedding | Embedding | 1 |
| LLM fallback route classification | LLM (structured output) | 1 |
| Policy Search API call | HTTP | 1 |
| **Total LLM calls** | | **2** |
| **Total service calls** | | **1** |

---

## 3. L1 IT-Support Query

**Example prompts:**
- "My VPN connection keeps dropping"
- "Please reset my password"
- "I can't access my email account"

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant L1 as L1 Adapter
    participant L1S as L1 AIOps Service
    participant F as UI Formatter

    U->>R: "My VPN keeps dropping"
    Note over R: Embed + cosine → L1_SUPPORT
    R->>L1: route = L1_SUPPORT
    L1->>L1S: POST /api/v1/invoke {query, employee_id, session_id}
    L1S-->>L1: {response_text, ticket_id, status}
    Note over L1: Build TEXT block + CARD block (if ticket created)
    L1->>F: pending_ui_blocks
    F-->>U: Response envelope
```

### Call Breakdown

| Operation | Type | Best | Worst |
|---|---|---|---|
| Follow-up classification | LLM | 0 | 1 |
| Prompt embedding | Embedding | 1 | 1 |
| Route classification | LLM | 0 | 1 |
| L1 AIOps invoke | HTTP | 1 | 1 |
| **Total LLM** | | **0** | **2** |
| **Total HTTP** | | **1** | **1** |

---

## 4. L2 Application Issue Query

**Example prompts:**
- "The SAP application is throwing an error when I submit expenses"
- "ServiceNow ticket creation is failing with a 500 error"
- "Application performance is degraded for the billing module"

This is the most complex flow with a **two-step downstream process**:

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant L2 as L2 Adapter
    participant CL as L2 Classifier
    participant AG as L2 Agent
    participant F as UI Formatter

    U->>R: "SAP expense submission error"
    Note over R: Embed + cosine → L2_APPLICATION
    R->>L2: route = L2_APPLICATION
    
    rect rgb(240, 248, 255)
        Note over L2,AG: Two-step L2 flow (if MAX_ORCHESTRATOR_CALL=true)
        L2->>CL: POST /api/v1/classify {query, employee_id}
        CL-->>L2: {application: "SAP", confidence: 0.92}
        L2->>AG: POST /api/v1/invoke {query, classification}
        AG-->>L2: {response_text, ticket_id, status}
    end
    
    Note over L2: Build TEXT + QUICK_REPLIES + CARD blocks
    Note over L2: Set l2_satisfaction = PENDING
    L2->>F: pending_ui_blocks
    F-->>U: Response with "Was this helpful?" quick-replies
```

### Call Breakdown

| Operation | Type | Best | Worst |
|---|---|---|---|
| Follow-up classification | LLM | 0 | 1 |
| Prompt embedding | Embedding | 1 | 1 |
| Route classification | LLM | 0 | 1 |
| L2 child classifier | HTTP | 1 | 1 |
| L2 agent invoke | HTTP | 1 | 1 |
| **Total LLM** | | **0** | **2** |
| **Total HTTP** | | **2** | **2** |

### L2 Fallback to L1

If `MAX_ORCHESTRATOR_CALL=false` or `L2_CLASSIFIER_ENABLED=false`, the L2 adapter
falls back to the L1 AIOps agent (spec §5):

```mermaid
sequenceDiagram
    participant L2 as L2 Adapter
    participant L1S as L1 AIOps Service

    Note over L2: L2 classifier disabled or unavailable
    L2->>L1S: POST /api/v1/invoke {query, is_escalation: false}
    L1S-->>L2: {response_text, ticket_id}
```

---

## 5. Leave Management

**Example prompts:**
- "I want to apply for leave next Friday"
- "Cancel my leave request for October"
- "Apply for vacation from Dec 20 to Dec 31"

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant DC as Direct Capability
    participant HR as HR Service
    participant F as UI Formatter

    U->>R: "Apply for leave next Friday"
    Note over R: Embed + cosine → LEAVE
    R->>DC: route = LEAVE
    DC->>HR: POST /api/v1/employees/{id}/leave {action: "query", prompt}
    HR-->>DC: {status, message}
    Note over DC: Format leave response into TEXT block
    DC->>F: pending_ui_blocks
    F-->>U: Response envelope
```

### Call Breakdown

| Operation | Type | Best | Worst |
|---|---|---|---|
| Follow-up classification | LLM | 0 | 1 |
| Prompt embedding | Embedding | 1 | 1 |
| Route classification | LLM | 0 | 1 |
| HR leave API | HTTP | 1 | 1 |
| **Total LLM** | | **0** | **2** |
| **Total HTTP** | | **1** | **1** |

---

## 6. Leave Balance Check

**Example prompts:**
- "How many vacation days do I have left?"
- "Show my leave balance"
- "What is my remaining PTO?"

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant DC as Direct Capability
    participant HR as HR Service
    participant F as UI Formatter

    U->>R: "Show my leave balance"
    Note over R: Embed + cosine → LEAVE_BALANCE
    R->>DC: route = LEAVE_BALANCE
    DC->>HR: GET /api/v1/employees/{id}/leave-balance
    HR-->>DC: {balances: [{type, remaining, total}]}
    Note over DC: Format into structured balance display
    DC->>F: pending_ui_blocks
    F-->>U: Response with formatted balance table
```

---

## 7. Self Info Query

**Example prompts:**
- "What is my employee ID?"
- "Who is my manager?"
- "What department am I in?"

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant DC as Direct Capability
    participant HR as HR Service
    participant F as UI Formatter

    U->>R: "Who is my manager?"
    Note over R: Embed + cosine → SELF_INFO
    R->>DC: route = SELF_INFO
    DC->>HR: GET /api/v1/employees/{id}/profile
    HR-->>DC: {profile: {name, department, manager, ...}}
    Note over DC: Format profile into markdown list
    DC->>F: pending_ui_blocks
    F-->>U: Formatted profile information
```

---

## 8. HIS Plan Query

**Example prompts:**
- "Show my health insurance plan details"
- "What is my current medical coverage?"
- "I want to see my HIS plan"

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant DC as Direct Capability
    participant HR as HR Service
    participant F as UI Formatter

    U->>R: "Show my HIS plan details"
    Note over R: Embed + cosine → HIS_PLAN
    R->>DC: route = HIS_PLAN
    DC->>HR: GET /api/v1/employees/{id}/his-plan
    HR-->>DC: {plan: {plan_name, provider, coverage_type, ...}}
    Note over DC: Format plan details into markdown list
    DC->>F: pending_ui_blocks
    F-->>U: Formatted HIS plan information
```

---

## 9. Beneficiaries Query

**Example prompts:**
- "Who are my listed beneficiaries?"
- "I need to update my beneficiary information"
- "Show my beneficiaries list"

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant DC as Direct Capability
    participant HR as HR Service
    participant F as UI Formatter

    U->>R: "Show my beneficiaries"
    Note over R: Embed + cosine → BENEFICIARIES
    R->>DC: route = BENEFICIARIES
    DC->>HR: GET /api/v1/employees/{id}/beneficiaries
    HR-->>DC: {beneficiaries: [{name, relationship, percentage}]}
    Note over DC: Format beneficiary list
    DC->>F: pending_ui_blocks
    F-->>U: Formatted beneficiary information
```

---

## 10. Timesheet Management

**Example prompts:**
- "Submit my timesheet for this week"
- "I need to correct my timesheet entry for Monday"
- "How do I fill in my timesheet?"

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant DC as Direct Capability
    participant HR as HR Service
    participant F as UI Formatter

    U->>R: "Submit my timesheet for this week"
    Note over R: Embed + cosine → TIMESHEET
    R->>DC: route = TIMESHEET
    DC->>HR: POST /api/v1/employees/{id}/timesheet {action: "query", prompt}
    HR-->>DC: {status, message}
    DC->>F: pending_ui_blocks
    F-->>U: Timesheet confirmation
```

---

## 11. Clarification / Unknown Intent

**Example prompts:**
- "What do you mean?"
- "Tell me more about that"
- *Any unrecognised input*

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant CA as Clarification Adapter
    participant F as UI Formatter

    U->>R: "What do you mean?"
    Note over R: Embed + cosine → CLARIFICATION
    R->>CA: route = CLARIFICATION
    Note over CA: Generate clarification prompt (no service call)
    CA->>F: TEXT block with clarification question
    F-->>U: "Could you elaborate on your question?"
```

### Call Breakdown

| Operation | Type | Best | Worst |
|---|---|---|---|
| Follow-up classification | LLM | 0 | 1 |
| Prompt embedding | Embedding | 1 | 1 |
| Route classification | LLM | 0 | 1 |
| Service calls | HTTP | **0** | **0** |
| **Total LLM** | | **0** | **2** |

---

## 12. Deviation Detection

**Scenario:** User was asking about leave balance, then suddenly asks about
password reset.

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant DH as Deviation Handler
    participant F as UI Formatter

    U->>R: "Reset my password" (after leave balance query)
    Note over R: 1. Follow-up classifier → DEVIATION (1 LLM call)
    Note over R: 2. Embed prompt (would route to L1)
    Note over R: 3. But deviation detected → override to deviation handler
    R->>DH: follow_up_status = DEVIATION
    Note over DH: Generate topic-switch prompt
    DH->>F: TEXT + QUICK_REPLIES blocks
    F-->>U: "You're switching topics. Continue previous or start new?"
```

### Call Breakdown

| Operation | Type | Count |
|---|---|---|
| Follow-up classification | LLM (structured output) | 1 |
| Prompt embedding | Embedding | 1 |
| Service calls | HTTP | **0** |
| **Total LLM** | | **1** |

---

## 13. L2 Satisfaction → Escalation

**Scenario:** User received an L2 application support response but is unsatisfied.

```mermaid
sequenceDiagram
    participant U as User
    participant API as API Edge
    participant R as Semantic Router
    participant L1 as L1 Adapter
    participant L1S as L1 AIOps Service
    participant F as UI Formatter

    Note over U: Previous turn: L2 response with "Was this helpful?" prompt
    U->>API: {prompt: "No", l2_satisfaction_response: "No, escalate"}
    Note over API: Set l2_satisfaction = UNSATISFIED in initial state
    API->>R: Graph invoke
    Note over R: State has l2_satisfaction = "unsatisfied"
    Note over R: FORCED ESCALATION (spec §5)
    Note over R: Skip normal routing → ESCALATION
    R->>L1: route = ESCALATION, confidence = 1.0
    L1->>L1S: POST /api/v1/invoke {is_escalation: true}
    L1S-->>L1: {response_text, ticket_id}
    Note over L1: Add DISCLAIMER: "Escalated to human agent"
    L1->>F: TEXT + CARD + DISCLAIMER blocks
    F-->>U: Escalation confirmation with ticket details
```

### Call Breakdown

| Operation | Type | Count |
|---|---|---|
| Follow-up classification | LLM | 0 (skipped – forced escalation) |
| Prompt embedding | Embedding | 0 (skipped) |
| L1 AIOps escalation | HTTP | 1 |
| **Total LLM** | | **0** |
| **Total HTTP** | | **1** |

---

## 14. Follow-Up on Previous Query

**Scenario:** User asks a follow-up question about the same topic.

```mermaid
sequenceDiagram
    participant U as User
    participant R as Semantic Router
    participant Adapter as Same Adapter as Before
    participant Svc as Same Service
    participant F as UI Formatter

    Note over U: Previous: "What is my leave balance?" → LEAVE_BALANCE
    U->>R: "And what about sick days specifically?"
    Note over R: 1. Follow-up classifier → FOLLOW_UP (1 LLM call)
    Note over R: 2. Embed prompt + cosine → LEAVE_BALANCE
    Note over R: 3. Normal routing (follow-up doesn't override)
    R->>Adapter: route = LEAVE_BALANCE
    Adapter->>Svc: HR Service call
    Svc-->>Adapter: Response
    Adapter->>F: blocks
    F-->>U: Updated leave balance (sick days focus)
```

---

## 15. Auxiliary Endpoints

These endpoints operate independently of the StateGraph.

### POST /speech_to_text

```mermaid
sequenceDiagram
    participant U as User
    participant API as API Edge
    participant SS as Speech Service

    U->>API: POST /speech_to_text (multipart audio file)
    API->>SS: POST /api/v1/transcribe (file upload)
    SS-->>API: {transcript, language, confidence}
    API-->>U: {status: ok, transcript: "..."}
```

**Calls:** 0 LLM, 1 HTTP

### POST /text_to_speech

```mermaid
sequenceDiagram
    participant U as User
    participant API as API Edge
    participant SS as Speech Service

    U->>API: POST /text_to_speech {text: "..."}
    API->>SS: POST /api/v1/synthesize {text, voice, format}
    SS-->>API: {audio_url, duration_seconds}
    API-->>U: {status: ok, audio_url: "..."}
```

**Calls:** 0 LLM, 1 HTTP

### POST /file-scan

```mermaid
sequenceDiagram
    participant U as User
    participant API as API Edge
    participant IC as ICAP Scanner

    U->>API: POST /file-scan (multipart file)
    API->>IC: POST /api/v1/scan (file upload)
    IC-->>API: {clean: true/false, threats: [...]}
    API-->>U: {status: ok, clean: true}
```

**Calls:** 0 LLM, 1 HTTP

### POST /feedback

```mermaid
sequenceDiagram
    participant U as User
    participant API as API Edge
    participant FB as Feedback Service

    U->>API: POST /feedback {rating, comment, session_id}
    API->>FB: POST /api/v1/feedback (feedback_data)
    FB-->>API: {status: ok}
    API-->>U: {status: ok}
```

**Calls:** 0 LLM, 1 HTTP

---

## Response Envelope Format

Every response from `POST /intent-handler` follows this structure:

```json
{
  "response": [
    {"type": "text", "content": "...", "metadata": {}},
    {"type": "reference", "content": {"title": "...", "source": "..."}, "metadata": {}},
    {"type": "quick_replies", "content": {"prompt": "...", "options": [...]}, "metadata": {}},
    {"type": "card", "content": {"title": "...", "ticket_id": "..."}, "metadata": {}},
    {"type": "disclaimer", "content": "...", "metadata": {}}
  ],
  "metadata": {
    "feedback_enabled": true,
    "ui_thread_id": "session-abc",
    "attachment_state": {"has_attachments": false, "count": 0},
    "user_action_required": false,
    "correlation_id": "uuid-...",
    "routed_to": "policy",
    "processing_time_ms": 145.2,
    "timing": {
      "correlation_id": "uuid-...",
      "total_ms": 145.2,
      "llm_calls": 0,
      "service_calls": 1,
      "operations": [
        {"op": "input_validation", "ms": 0.3, "ok": true},
        {"op": "checkpointer_init", "ms": 12.1, "ok": true},
        {"op": "graph_build_and_compile", "ms": 1.5, "ok": true},
        {"op": "router_followup_classification", "ms": 0.1, "ok": true},
        {"op": "embed_user_prompt", "ms": 35.2, "ok": true},
        {"op": "cosine_similarity_search", "ms": 0.8, "ok": true},
        {"op": "service_call_policy_search", "ms": 89.4, "ok": true, "service": "policy"},
        {"op": "ui_formatter_normalisation", "ms": 0.5, "ok": true},
        {"op": "response_extraction", "ms": 0.2, "ok": true},
        {"op": "graph_invoke", "ms": 130.1, "ok": true}
      ]
    }
  }
}
```
